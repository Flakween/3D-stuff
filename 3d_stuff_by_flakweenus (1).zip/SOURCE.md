# TurboWarp source

This project includes a static build of TurboWarp's `scratch-gui`, built from commit [`a2946eeb9a9dca7857d7ab53d766b54288c7a2ff`](https://github.com/TurboWarp/scratch-gui/tree/a2946eeb9a9dca7857d7ab53d766b54288c7a2ff).

TurboWarp's modifications are licensed under GPL-3.0; see [LICENSE](LICENSE).

This fork serves the editor at `index.html`. Local changes to the prebuilt GUI
are in `js/editor.js`: project-page navigation and sharing controls are removed,
the catalog add buttons use Paint, Upload, or Record, and catalog loading is
disabled. Project thumbnail callers prefer the 3D stage capture interface.
Standalone player/embed pages, catalog chunks, and source maps were
removed. A future rebuild from upstream source must reapply these changes.

Nonessential bundled illustrations and thumbnails now resolve to a transparent
inline SVG or the editor's extension button icon. The original files, app icons,
and micro:bit firmware were removed. The extension catalog contains only the
custom extension loader; the built-in extension registry, compiled extension
modules, online gallery fetch, Music samples, and extension block icons were
removed. Projects with removed extension IDs load their core blocks without
trying to fetch those extensions. Custom extensions still load by URL, file, or
source code, including URLs stored in project metadata. Blockly feedback sounds,
paint tools, and core block media remain because active editor features use them.

The 3D update lives in `three-editor.js` and `three-editor.css`. It presents a
model workspace in the costumes tab and draws actors with a separate Three.js
WebGL canvas layered over TurboWarp's stage. The 3D stage reads target state and
script ticks through an adapter; it does not query the native canvas or patch
the native renderer's draw and snapshot methods. Procedural textures use pixel
data, and model thumbnails and uploaded sky image resizing use WebGL surfaces;
the 3D module has no 2D canvas context. TurboWarp's own renderer and
compiled block engine remain present for legacy project behavior, including
2D sensing and pen. The 3D stage exposes `captureFrame()` for its own frame;
project thumbnail code asks that interface for a 3D image. TurboWarp's native
snapshot API is no longer redirected to it.
`three-runtime-core.js` owns that adapter's event lifecycle, Scratch-to-world
coordinate mapping, and model hierarchy validation. Primitive and material
data are stored in local storage; imported model files are stored in IndexedDB.

For the stage target, the second tab is Scenes. Each stage costume is a scene
with its own skybox, fog, post effects, lighting, and ground settings. These
settings are stored alongside the 3D actor data in the project archive and the
local project cache. Switching stage costumes from scripts switches the rendered
scene settings too.
The visible Motion flyout now uses 3D extension opcodes for movement, turning,
pointing, x/y/z positioning, gliding, axis changes, and position reporters.
Pitch controls the vertical component of forward movement; x/y/z blocks all
use Scratch units (60 units per world unit). Saved legacy height opcodes retain
their world-unit interpretation and older Scratch motion opcodes remain loadable.
The 3D position commands update target state directly rather than routing
through the 2D drawable and its stage fencing. Model selection by name remains
in Looks. Clone model choices are runtime-only; an original sprite's selected
model is stored with its actor. Runtime transforms are flushed with a bounded
delay so continuously changing scripts cannot starve local persistence.

## Model editor controls

`editor-ui.js` defines the contextual toolbar and anchored popovers;
`three-editor.js` binds them to the persisted model data. Color contains the picker, hex input, metallic, smoothness and opacity; Material
contains image-map uploads, replacement previews and removal controls.
Name fields are shown only with the selection tool; parenting actions share
one group beside the selection controls. Transform controls invalidate the
viewport on changes, including handle mode, space, and hover changes.
`wireframe-overlay.js` adds black wire meshes over the shaded surfaces. It
shares surface geometry and skeletons, and restores material depth offsets
when disabled or rebuilt. These helpers are never saved or exported.
`mesh-subdivision.js` provides welded Loop smoothing and linear refinement,
retaining UV seams. Refinement factors are 1, 2, 4, 8 and 16.

The three transform handles share a proxy: world operations use the selection's
bounds, while local operations use the last selected object's saved pivot.
Edit Local supports translation and rotation and compensates the direct model
content and child transforms. Imported scene roots use the same persisted
`meshPosition`, `meshRotation` and `meshScale` fields as primitives. Parenting
preserves world transforms and uses selection order. As with Three.js TRS
transforms, rotated objects under nonuniformly scaled parents cannot represent
arbitrary shear exactly.

Imports currently support GLB, glTF with embedded resources, and OBJ geometry.
For multi-file glTF/OBJ packages, extend `importModel` and `loadImportedTemplate`
with a file-bundle resolver (including .bin, images and .mtl); the input currently
accepts a single model file. Project archives already include imported model
bytes through the existing asset hooks. Texture overrides are data URLs in each
object's `maps` field. Export rebuilds saved materials, so viewport shading modes
are not baked into the exported model.
