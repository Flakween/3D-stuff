import { subdivideMesh } from "./mesh-subdivision.js";
import { editorMarkup } from "./editor-ui.js";
import { WireframeOverlay } from "./wireframe-overlay.js";
import { captureRuntimeSettings, restoreRuntimeSettings, installRuntimeSettings } from "./runtime-settings.js";
import {
  Runtime3DBridge,
  forwardStep3D,
  sanitizeObjectHierarchy,
  SCRATCH_UNITS_PER_WORLD_UNIT,
  scratchTargetPose,
} from "./three-runtime-core.js";
import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { TransformControls } from "three/addons/controls/TransformControls.js";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { OBJLoader } from "three/addons/loaders/OBJLoader.js";
import { GLTFExporter } from "three/addons/exporters/GLTFExporter.js";
import { clone as cloneSkeleton } from "three/addons/utils/SkeletonUtils.js";

const LEGACY_STORAGE_KEY = "dango-3d-models-v1";
const STORAGE_PREFIX = "dango-3d-scene-v2:";
const PROJECT_FIELD = "dango3d";
const ASSET_PATH = "dango3d/assets";
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const uiIcon = (name, size = 24) => {
  const paths = {
    copy: '<path d="M5 2h9l5 5v15a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2Z" fill="currentColor"/><path d="M14 2v5h5" fill="#ffb3b3"/><path d="M11 11v7m-3.5-3.5h7" stroke="#fff" stroke-width="2" stroke-linecap="round"/>',
    paste: '<path d="M5 2h9l5 5v15a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2Z" fill="currentColor"/><path d="M14 2v5h5" fill="#ffb3b3"/><path d="M11 10v8m0 0-3-3m3 3 3-3" stroke="#141414" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>',
    delete: '<path d="M4 5h16v3H4zm5-2h6v2H9zM5.5 9h13l-1.2 13.5a2 2 0 0 1-2 1.5H8.7a2 2 0 0 1-2-1.5Z" fill="currentColor"/><path d="m9.5 12 .5 8.5M12 12v8.5m2.5-8.5-.5 8.5" stroke="#141414" stroke-width="1.5" stroke-linecap="round"/>',
    undo: '<path d="M7 3 2.5 7.2 7 11.4V8.5c4.2 0 6.8 1.3 8.2 4-1-4.5-3.6-6.9-8.2-6.9V3Z" fill="currentColor"/>',
    redo: '<path d="m11 3 4.5 4.2-4.5 4.2V8.5c-4.2 0-6.8 1.3-8.2 4 1-4.5 3.6-6.9 8.2-6.9V3Z" fill="currentColor"/>',
    select: '<path d="M5 2v18l4.3-4 3 6 2.8-1.4-3.1-6.2h6Z" fill="currentColor"/>',
    gizmo: '<path d="M16 16V4m0 0-3 3m3-3 3 3M16 16 5 22m0 0 1-4m-1 4 4 .5M16 16l11 6m0 0-4 .5m4-.5-1-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="m16 12 4 2.5v5L16 22l-4-2.5v-5Z" fill="#141414" stroke="currentColor" stroke-width="1.3"/><path d="m12 14.5 4 2.5 4-2.5M16 17v5" stroke="currentColor" stroke-width="1.2"/>',
    shapes: '<path d="m9 6 6 19H3Zm11-1a5 5 0 1 1 0 10 5 5 0 0 1 0-10Zm-3 12h10v9H17Z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round" fill="none"/>',
    wire: '<path d="m5 5 11-2 4 4v11L9 20l-4-4Zm0 0 4 4 11-2M9 9v11M9 9l11 9" stroke="currentColor" stroke-width="1.3" fill="none"/>',
    tree: '<path d="M6 3v16m0-8h6m-6 6h6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="6" cy="5" r="2" fill="currentColor"/><circle cx="15" cy="11" r="2" fill="currentColor"/><circle cx="15" cy="17" r="2" fill="currentColor"/>',
    grid: '<path d="M8 3v16m6-16v16M3 8h16M3 14h16" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
    moon: '<path d="M10.5 3c3.3 1.2 5 5 3.7 8.8-1 2.9-3.7 4.7-6.7 4.9 2.7-1.9 3.8-5.5 2.7-9-.5-1.8-1.6-3.3-3-4.3 1.1-.4 2.2-.5 3.3-.4Z" fill="currentColor"/>',
    zoomOut: '<circle cx="8" cy="8" r="5.5" stroke="currentColor" stroke-width="1.6" fill="none"/><path d="M5.5 8h5m2 4 3.5 3.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
    zoomIn: '<circle cx="8" cy="8" r="5.5" stroke="currentColor" stroke-width="1.6" fill="none"/><path d="M5.5 8h5M8 5.5v5m4.5 1.5 3.5 3.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
    zoomReset: '<path d="M5 7h8M5 11h8" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
  };
  const viewBox = ["gizmo", "shapes"].includes(name) ? "0 0 32 32" : ["copy", "paste", "delete"].includes(name) ? "0 0 24 26" : name.startsWith("zoom") ? "0 0 18 18" : "0 0 24 24";
  return `<svg width="${size}" height="${size}" viewBox="${viewBox}" fill="none" aria-hidden="true">${paths[name]}</svg>`;
};
const uid = () => crypto.randomUUID();
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
const state = {
  actors: Object.create(null),
  scenes: [],
  targetTransforms: new Map(),
  projectId: null,
  storageKey: null,
  projectSignature: null,
  selected: [],
  tool: "select",
  transform: "all",
  space: "world",
  view: "rendered",
  filter: "all",
  showHierarchy: true,
  boxSelect: false,
  exposure: 1.25,
  grid: true,
};
let sceneRevision = 0;
const actorRevisions = new Map();
const actorLookup = new WeakMap();
const cloneModels = new Map();
let saveTimer;
let projectChangeTimer;
let projectLoadedOnce = false;
let projectLoading = false;
let readyPromise = Promise.resolve();
const hookedVMs = new WeakSet();
let sceneEditor = null;
const assetBytes = new Map();
const projectIdPromise = resolveProjectId();
const OBJECT_TYPES = new Set([
  "cube",
  "sphere",
  "cone",
  "cylinder",
  "plane",
  "torus",
  "star",
  "import",
  "empty",
]);
const MAP_TYPES = new Set([
  "texture",
  "roughness",
  "metallic",
  "normal",
  "opacity",
]);
const SAFE_ASSET_ID = /^[a-z0-9_-]{1,128}$/i;
const MODEL_COORDINATE_LIMIT = 1e6;

function finiteNumber(value, fallback, min = -Infinity, max = Infinity) {
  const number = Number(value);
  return Number.isFinite(number) ? clamp(number, min, max) : fallback;
}

function vector3(value, fallback) {
  const validArray = Array.isArray(value) || ArrayBuffer.isView(value);
  return fallback.map((defaultValue, index) =>
    validArray
      ? finiteNumber(
          value[index],
          defaultValue,
          -MODEL_COORDINATE_LIMIT,
          MODEL_COORDINATE_LIMIT,
        )
      : defaultValue,
  );
}

function safeModelName(value, fallback) {
  return typeof value === "string" && value
    ? value.slice(0, 256)
    : typeof fallback === "string" && fallback
      ? fallback.slice(0, 256)
      : "Model";
}

function safeAssetId(value) {
  return typeof value === "string" && SAFE_ASSET_ID.test(value)
    ? value
    : null;
}

function uniqueId(value, used) {
  let id =
    typeof value === "string" && value.length > 0 && value.length <= 128
      ? value
      : uid();
  while (used.has(id)) id = uid();
  used.add(id);
  return id;
}

function isBase64Payload(value) {
  const separator = value.lastIndexOf(",");
  const hasDataURLHeader = separator >= 0;
  if (
    hasDataURLHeader &&
    !/^data:[^,]*;base64$/i.test(value.slice(0, separator))
  ) return false;
  const payload = hasDataURLHeader ? value.slice(separator + 1) : value;
  const padded = /^(?:[a-z0-9+/]{4})*(?:[a-z0-9+/]{2}==|[a-z0-9+/]{3}=)?$/i;
  const unpadded = /^(?:[a-z0-9+/]{4})*(?:[a-z0-9+/]{2,3})?$/i;
  return padded.test(payload) || unpadded.test(payload);
}

function normalizeMaps(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return {};
  const maps = {};
  for (const key of MAP_TYPES) {
    const url = value[key];
    // Textures created by this editor are embedded data URLs. Reject remote
    // URLs from imported project data to avoid unexpected third-party requests.
    if (typeof url === "string" && /^data:image\//i.test(url)) maps[key] = url;
  }
  return maps;
}

function normalizeSource(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const assetId = safeAssetId(value.assetId);
  if (!assetId) return null;
  const format = ["glb", "gltf", "obj"].includes(value.format)
    ? value.format
    : "glb";
  const source = { format, assetId };
  if (typeof value.data === "string" && isBase64Payload(value.data)) {
    source.data = value.data;
  }
  return source;
}

async function resolveProjectId() {
  const fromPath = location.pathname.match(/\/p\/([^/]+)/)?.[1];
  if (fromPath) return fromPath;
  for (let attempt = 0; attempt < 30; attempt++) {
    try {
      const project = await window.websim?.getCurrentProject?.();
      if (project?.id) return String(project.id);
    } catch {
      // Local preview may start before its Websim identity bootstrap is ready.
    }
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  return `local:${location.origin}${location.pathname}`;
}

function scheduleProjectChanged() {
  clearTimeout(projectChangeTimer);
  projectChangeTimer = setTimeout(() => {
    const vm = window.vm;
    if (vm?.runtime?.emitProjectChanged) vm.runtime.emitProjectChanged();
  }, 300);
}

function save({
  projectChanged = true,
  sceneChanged = false,
  actorName = null,
  bumpRevision = true,
  recordHistory = true,
} = {}) {
  if (bumpRevision) {
    if (actorName) {
      actorRevisions.set(actorName, (actorRevisions.get(actorName) || 0) + 1);
    } else sceneRevision++;
  }
  if (sceneChanged) stage?.markDirty(actorName);
  if (recordHistory) editor?.recordHistory();
  clearTimeout(saveTimer);
  saveTimer = setTimeout(flushSave, 180);
  if (projectChanged) scheduleProjectChanged();
}

const defaultSceneSettings = () => ({
  skyMode: "gradient", skyColor: "#ff9c5c", skyTexture: null,
  fogEnabled: false, fogColor: "#ffffff", fogDensity: 0.015,
  exposure: 1.25, brightness: 1, contrast: 1, saturation: 1,
  shadows: true, groundColor: "#999b9d", ambient: 1.7, sun: 3.2,
});
function normalizeSceneSettings(input = {}) {
  input ||= {};
  const result = defaultSceneSettings();
  if (["gradient", "color", "texture"].includes(input.skyMode)) result.skyMode = input.skyMode;
  for (const key of ["skyColor", "fogColor", "groundColor"])
    if (/^#[0-9a-f]{6}$/i.test(input[key])) result[key] = input[key];
  if (typeof input.skyTexture === "string" && /^data:image\/(?:png|jpeg|webp);base64,/.test(input.skyTexture)) result.skyTexture = input.skyTexture;
  for (const [key, min, max] of [["fogDensity",0,.1],["exposure",.25,3],["brightness",.5,1.5],["contrast",.5,1.5],["saturation",0,2],["ambient",0,4],["sun",0,6]]) {
    const value = Number(input[key]);
    if (Number.isFinite(value)) result[key] = clamp(value, min, max);
  }
  result.fogEnabled = !!input.fogEnabled;
  result.shadows = input.shadows !== false;
  return result;
}
function normalizeScenes(source) {
  return Array.isArray(source) ? source.filter((item) => item && typeof item === "object")
    .map((item) => ({ name: safeModelName(item.name, "Scene"), settings: normalizeSceneSettings(item.settings) })) : [];
}
function sceneSettings(index) {
  return state.scenes[index]?.settings || defaultSceneSettings();
}
function reconcileScenes() {
  const stageTarget = window.vm?.runtime?.getTargetForStage?.();
  const costumes = stageTarget?.getCostumes?.() || [];
  if (!costumes.length) return;
  const old = state.scenes || [];
  if (old.length === costumes.length && old.every((item, i) => item.name === costumes[i].name && item.settings)) return;
  const used = new Set();
  const matches = costumes.map((costume) => old.findIndex((item) => item.name === costume.name));
  for (const match of matches) if (match >= 0) used.add(match);
  const next = costumes.map((costume, index) => {
    let match = matches[index];
    if (match < 0 && old[index] && !used.has(index)) match = index;
    if (match >= 0) used.add(match);
    return { name: costume.name, settings: normalizeSceneSettings(old[match]?.settings) };
  });
  if (JSON.stringify(old) !== JSON.stringify(next)) {
    state.scenes = next;
    flushSave();
  }
}

window.addEventListener("pagehide", flushSave);
const norm = (obj) => ({
  id: typeof obj?.id === "string" && obj.id.length > 0 && obj.id.length <= 128 ? obj.id : uid(),
  name: safeModelName(obj?.name, typeof obj?.type === "string" ? obj.type : "cube"),
  type: OBJECT_TYPES.has(obj?.type) ? obj.type : "cube",
  parent: typeof obj?.parent === "string" && obj.parent.length > 0 && obj.parent.length <= 128 ? obj.parent : null,
  position: vector3(obj?.position, [0, 0, 0]),
  rotation: vector3(obj?.rotation, [0, 0, 0]),
  scale: vector3(obj?.scale, [1, 1, 1]),
  meshPosition: vector3(obj?.meshPosition, [0, 0, 0]),
  meshRotation: vector3(obj?.meshRotation, [0, 0, 0]),
  meshScale: vector3(obj?.meshScale, [1, 1, 1]),
  color: typeof obj?.color === "string" && /^#[0-9a-f]{6}$/i.test(obj.color) ? obj.color : "#ffffff",
  metallic: finiteNumber(obj?.metallic, 0.1, 0, 1),
  smoothness: finiteNumber(obj?.smoothness, 0.72, 0, 1),
  opacity: finiteNumber(obj?.opacity, 1, 0, 1),
  materialOverride: typeof obj?.materialOverride === "boolean"
    ? obj.materialOverride
    : obj?.type !== "import",
  subdivisions: 2 ** Math.ceil(Math.log2(finiteNumber(obj?.subdivisions, 1, 1, 16))),
  linear: !!obj?.linear,
  points: Math.round(finiteNumber(obj?.points, 5, 3, 24)),
  innerAngle: finiteNumber(obj?.innerAngle, 120, 30, 175),
  width: finiteNumber(obj?.width, 1, 0.05, 10000),
  depth: finiteNumber(obj?.depth, 1, 0.05, 10000),
  height: finiteNumber(obj?.height, 1, 0.05, 10000),
  maps: normalizeMaps(obj?.maps),
  source: normalizeSource(obj?.source),
});
function defaultCone() {
  return norm({
    type: "cone",
    name: "Cone",
    width: 1.65,
    depth: 1.65,
    height: 2.7,
    position: [0, 1.35, 0],
    metallic: 0.88,
    smoothness: 0.85,
    color: "#ffffff",
    subdivisions: 4,
  });
}
function normalizeActor(data, fallbackName = "Actor") {
  const models = Array.isArray(data?.models)
    ? data.models.filter((model) => model && typeof model === "object")
    : [];
  const usedModelIds = new Set();
  return {
    name: safeModelName(data?.name, fallbackName),
    active: Math.round(clamp(finiteNumber(data?.active, 0), 0, Math.max(models.length - 1, 0))),
    transform3D: {
      height: finiteNumber(data?.transform3D?.height, 0, -MODEL_COORDINATE_LIMIT, MODEL_COORDINATE_LIMIT),
      yaw: finiteNumber(data?.transform3D?.yaw, 0, -MODEL_COORDINATE_LIMIT, MODEL_COORDINATE_LIMIT),
      pitch: finiteNumber(data?.transform3D?.pitch, 0, -MODEL_COORDINATE_LIMIT, MODEL_COORDINATE_LIMIT),
      roll: finiteNumber(data?.transform3D?.roll, 0, -MODEL_COORDINATE_LIMIT, MODEL_COORDINATE_LIMIT),
    },
    models: models.length
      ? models.map((model, index) => {
          const usedObjectIds = new Set();
          const objects = Array.isArray(model.objects)
            ? model.objects
                .filter((object) => object && typeof object === "object")
                .map((object) => {
                  const normalized = norm(object);
                  normalized.id = uniqueId(normalized.id, usedObjectIds);
                  return normalized;
                })
            : [];
          sanitizeObjectHierarchy(objects);
          return {
            id: uniqueId(model.id, usedModelIds),
            name: safeModelName(model.name, `Model ${index + 1}`),
            objects,
          };
        })
      : [{ id: uid(), name: "model1", objects: [] }],
  };
}

function dataForTarget(target) {
  if (!target || target.isStage) return null;
  if (state.actors[target.id]) return state.actors[target.id];
  const originalId = target.sprite?.clones?.[0]?.id;
  if (originalId && state.actors[originalId]) return state.actors[originalId];
  const cached = actorLookup.get(target.sprite);
  const name = target.sprite?.name;
  if (cached?.actors === state.actors && cached.data.name === name) return cached.data;
  const data = Object.values(state.actors).find(item => item?.name === name);
  if (data && target.sprite) actorLookup.set(target.sprite, { actors: state.actors, data });
  return data;
}

function actor() {
  const target = window.vm?.editingTarget;
  if (!target || target.isStage) return null;
  if (!state.actors[target.id]) {
    const first =
      window.vm.runtime.targets.filter((t) => !t.isStage && t.isOriginal)
        .length === 1;
    const existing = dataForTarget(target);
    state.actors[target.id] = normalizeActor(
      existing || {
        name: target.sprite.name,
        models: [
          { id: uid(), name: "model1", objects: first ? [defaultCone()] : [] },
        ],
        active: 0,
      },
      target.sprite.name,
    );
    save({
      projectChanged: false,
      sceneChanged: true,
      actorName: state.actors[target.id].name,
    });
  }
  if (state.actors[target.id].name !== target.sprite.name) {
    state.actors[target.id].name = target.sprite.name;
    save({ actorName: state.actors[target.id].name });
  }
  if (!state.actors[target.id].transform3D) {
    state.actors[target.id].transform3D = {
      height: 0,
      yaw: 0,
      pitch: 0,
      roll: 0,
    };
  }
  return state.actors[target.id];
}

function runtimeTransform(target, data = dataForTarget(target)) {
  if (!target) return { height: 0, yaw: 0, pitch: 0, roll: 0 };
  if (!state.targetTransforms.has(target.id)) {
    state.targetTransforms.set(target.id, {
      height: Number(data?.transform3D?.height) || 0,
      yaw: Number(data?.transform3D?.yaw) || 0,
      pitch: Number(data?.transform3D?.pitch) || 0,
      roll: Number(data?.transform3D?.roll) || 0,
    });
  }
  return state.targetTransforms.get(target.id);
}

function setRuntimeTransform(target, property, value, change = false) {
  if (
    !target ||
    target.isStage ||
    !["height", "yaw", "pitch", "roll"].includes(property)
  ) return;
  const current = runtimeTransform(target);
  const number = Number(value);
  if (!Number.isFinite(number)) return;
  const next = clamp(
    change ? current[property] + number : number,
    -MODEL_COORDINATE_LIMIT,
    MODEL_COORDINATE_LIMIT,
  );
  if (Object.is(current[property], next)) return;
  current[property] = next;
  if (target.isOriginal) {
    const data = dataForTarget(target);
    if (data) {
      data.transform3D ||= { height: 0, yaw: 0, pitch: 0, roll: 0 };
      data.transform3D[property] = current[property];
      scheduleRuntimeSave();
    }
  }
  stage?.invalidate();
  schedulePoseControlsSync();
}

function setTargetXY3D(target, x, y) {
  if (!target || target.isStage || target.dragging) return;
  const nextX = finiteNumber(x, target.x, -MODEL_COORDINATE_LIMIT, MODEL_COORDINATE_LIMIT);
  const nextY = finiteNumber(y, target.y, -MODEL_COORDINATE_LIMIT, MODEL_COORDINATE_LIMIT);
  if (nextX === target.x && nextY === target.y) return;
  const oldX = target.x;
  const oldY = target.y;
  target.x = nextX;
  target.y = nextY;
  target.onTargetMoved?.(target, oldX, oldY, false);
  target.runtime?.requestTargetsUpdate?.(target);
  stage?.invalidate();
}

function setPosition3D(target, x, y, z) {
  setTargetXY3D(target, x, y);
  setRuntimeTransform(target, "height", Number(z) / SCRATCH_UNITS_PER_WORLD_UNIT);
}

function positionZ(target) {
  return runtimeTransform(target).height * SCRATCH_UNITS_PER_WORLD_UNIT;
}

function setDirection3D(target, value) {
  if (!target || target.isStage) return;
  const number = Number(value);
  if (!Number.isFinite(number)) return;
  const direction = (((number + 179) % 360 + 360) % 360) - 179;
  if (target.direction === direction) return;
  target.direction = direction;
  target.runtime?.requestTargetsUpdate?.(target);
  stage?.invalidate();
  schedulePoseControlsSync();
}

let runtimeSaveTimer = 0;
let runtimeSaveMaxTimer = 0;
function scheduleRuntimeSave() {
  clearTimeout(runtimeSaveTimer);
  runtimeSaveTimer = setTimeout(flushSave, 500);
  if (!runtimeSaveMaxTimer) {
    runtimeSaveMaxTimer = setTimeout(() => {
      runtimeSaveMaxTimer = 0;
      clearTimeout(runtimeSaveTimer);
      runtimeSaveTimer = 0;
      flushSave();
    }, 2000);
  }
}

const activeModel = () => actor()?.models[actor().active];
const skyVertex =
  "varying vec3 vPos; void main(){vPos=position; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}";
const skyFragment =
  "uniform vec3 uSkyColor; varying vec3 vPos; void main(){float h=normalize(vPos).y; vec3 low=uSkyColor*vec3(1.0,.72,.55); vec3 mid=uSkyColor*vec3(1.0,1.1,1.05); vec3 high=uSkyColor*vec3(.89,.51,.61); vec3 c=mix(low,mid,smoothstep(-.2,.15,h)); c=mix(c,high,smoothstep(.05,.95,h)); gl_FragColor=vec4(c,1.0);}";
function sampledColor(stops, position) {
  const end = stops.findIndex(([stop]) => position <= stop);
  if (end <= 0) return stops[0][1].slice();
  const [startPosition, startColor] = stops[end - 1];
  const [endPosition, endColor] = stops[end];
  const fraction = (position - startPosition) / (endPosition - startPosition);
  return startColor.map((channel, index) => channel + (endColor[index] - channel) * fraction);
}

function pixelTexture(width, height, sample) {
  const pixels = new Uint8Array(width * height * 4);
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
    const color = sample(x, y);
    const offset = (y * width + x) * 4;
    pixels[offset] = color[0];
    pixels[offset + 1] = color[1];
    pixels[offset + 2] = color[2];
    pixels[offset + 3] = 255;
  }
  const texture = new THREE.DataTexture(pixels, width, height, THREE.RGBAFormat);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.magFilter = THREE.LinearFilter;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.generateMipmaps = true;
  texture.flipY = true;
  texture.needsUpdate = true;
  return texture;
}

function resizedImageDataURL(bitmap) {
  const scale = Math.min(1, 1024 / bitmap.width, 512 / bitmap.height);
  const width = Math.max(1, Math.round(bitmap.width * scale));
  const height = Math.max(1, Math.round(bitmap.height * scale));
  const canvas = document.createElement("canvas");
  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: false,
    alpha: false,
    preserveDrawingBuffer: true,
  });
  const texture = new THREE.Texture(bitmap);
  const geometry = new THREE.PlaneGeometry(2, 2);
  const material = new THREE.MeshBasicMaterial({ map: texture, toneMapped: false });
  try {
    renderer.setSize(width, height, false);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.flipY = false; // ImageBitmap was flipped when decoded for WebGL UVs.
    texture.needsUpdate = true;
    const scene = new THREE.Scene();
    scene.add(new THREE.Mesh(geometry, material));
    renderer.render(scene, new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1));
    return canvas.toDataURL("image/jpeg", 0.86);
  } finally {
    geometry.dispose();
    material.dispose();
    texture.dispose();
    renderer.dispose();
    renderer.forceContextLoss?.();
  }
}

function fileDataURL(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

function environment() {
  const stops = [
    [0, [238, 243, 255]], [.45, [255, 245, 232]],
    [.55, [255, 180, 110]], [1, [73, 76, 89]],
  ];
  const glows = [[100, 95, 55], [360, 100, 28], [445, 130, 14]];
  const tex = pixelTexture(512, 256, (x, y) => {
    const color = sampledColor(stops, y / 255);
    for (const [cx, cy, radius] of glows) {
      const distance = Math.hypot(x - cx, y - cy) / radius;
      const alpha = Math.max(0, 1 - distance) ** .65;
      for (let channel = 0; channel < 3; channel++) color[channel] += (255 - color[channel]) * alpha;
    }
    return color;
  });
  tex.mapping = THREE.EquirectangularReflectionMapping;
  return tex;
}
const envTexture = environment();
function matcap() {
  const stops = [
    [0, [255, 255, 255]], [.35, [255, 182, 109]],
    [.7, [156, 74, 49]], [1, [55, 42, 55]],
  ];
  return pixelTexture(128, 128, (x, y) =>
    sampledColor(stops, clamp((Math.hypot(x - 42, y - 34) - 4) / 76, 0, 1))
  );
}
const matcapTexture = matcap();
function makeScene(grid = false) {
  const scene = new THREE.Scene();
  scene.environment = envTexture;
  if (grid) scene.background = new THREE.Color(0x000000);
  else {
    const sky = new THREE.Mesh(
      new THREE.SphereGeometry(80, 24, 16),
      new THREE.ShaderMaterial({
        uniforms: { uSkyColor: { value: new THREE.Color("#ff9c5c").convertLinearToSRGB() } },
        vertexShader: skyVertex,
        fragmentShader: skyFragment,
        side: THREE.BackSide,
        depthWrite: false,
      }),
    );
    sky.name = "3D background";
    scene.add(sky);
  }
  scene.add(new THREE.HemisphereLight(0xffefdd, 0x8995a5, 1.7));
  const key = new THREE.DirectionalLight(0xffffff, 3.2);
  key.position.set(-3, 8, 5);
  key.castShadow = true;
  key.shadow.mapSize.set(1024, 1024);
  key.shadow.camera.near = 0.5;
  key.shadow.camera.far = 80;
  key.shadow.camera.left = -18;
  key.shadow.camera.right = 18;
  key.shadow.camera.top = 18;
  key.shadow.camera.bottom = -18;
  key.shadow.bias = -0.00015;
  scene.add(key);
  const fill = new THREE.DirectionalLight(0xffab68, 1.1);
  fill.position.set(5, 2, -4);
  scene.add(fill);
  const floor = new THREE.Mesh(
    new THREE.PlaneGeometry(200, 200),
    new THREE.MeshStandardMaterial({
      color: grid ? 0x080808 : 0x999b9d,
      roughness: 0.92,
      metalness: 0.03,
    }),
  );
  floor.name = "3D ground";
  floor.rotation.x = -Math.PI / 2;
  floor.position.y = -0.015;
  floor.receiveShadow = true;
  scene.add(floor);
  if (grid) {
    const helper = new THREE.GridHelper(40, 40, 0x7d5535, 0x555555);
    helper.name = "3D grid";
    helper.position.y = 0.005;
    helper.material.transparent = true;
    helper.material.opacity = 0.45;
    scene.add(helper);
  }
  return scene;
}
function makeRenderer(canvas, antialias = true, alpha = false) {
  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias,
    powerPreference: "default",
    alpha,
  });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = state.exposure;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  return renderer;
}
function starGeometry(points, inner, depth) {
  const shape = new THREE.Shape();
  for (let i = 0; i < points * 2; i++) {
    const a = (i * Math.PI) / points - Math.PI / 2,
      r = i % 2 ? inner : 1;
    const x = Math.cos(a) * r,
      y = Math.sin(a) * r;
    if (i === 0) shape.moveTo(x, y);
    else shape.lineTo(x, y);
  }
  shape.closePath();
  const g = new THREE.ExtrudeGeometry(shape, {
    depth: Math.max(0.05, depth),
    bevelEnabled: false,
    steps: 1,
  });
  g.center();
  g.rotateX(-Math.PI / 2);
  return g;
}
function geometry(d) {
  return subdivideMesh(primitiveGeometry({...d, subdivisions:1}), d.subdivisions, d.linear);
}
function primitiveGeometry(d) {
  const width = Math.max(0.05, Number(d.width) || 1);
  const height = Math.max(0.05, Number(d.height) || 1);
  const depth = Math.max(0.05, Number(d.depth) || 1);
  const subdivisions = clamp(Number(d.subdivisions) || 1, 1, 16);
  switch (d.type) {
    case "cube":
      return new THREE.BoxGeometry(
        width,
        height,
        depth,
        subdivisions,
        subdivisions,
        subdivisions,
      );
    case "sphere": {
      const g = new THREE.SphereGeometry(
        1,
        Math.max(12, subdivisions * 12),
        Math.max(8, subdivisions * 8),
      );
      g.scale(width / 2, height / 2, depth / 2);
      return g;
    }
    case "cylinder": {
      const g = new THREE.CylinderGeometry(
        1,
        1,
        height,
        Math.max(12, subdivisions * 12),
        subdivisions,
      );
      g.scale(width / 2, 1, depth / 2);
      return g;
    }
    case "cone": {
      const g = new THREE.ConeGeometry(
        1,
        height,
        Math.max(16, subdivisions * 16),
        subdivisions,
      );
      g.scale(width / 2, 1, depth / 2);
      return g;
    }
    case "plane": {
      const g = new THREE.PlaneGeometry(
        width,
        depth,
        subdivisions,
        subdivisions,
      );
      g.rotateX(-Math.PI / 2);
      return g;
    }
    case "torus": {
      const g = new THREE.TorusGeometry(
        width / 2,
        Math.max(0.06, height / 5),
        Math.max(6, subdivisions * 6),
        Math.max(16, subdivisions * 16),
      );
      g.scale(1, depth / Math.max(width, 0.05), 1);
      g.rotateX(-Math.PI / 2);
      return g;
    }
    case "star": {
      const points = clamp(Number(d.points) || 5, 3, 24);
      const angle = THREE.MathUtils.degToRad(
        clamp(Number(d.innerAngle) || 120, 30, 175),
      );
      const phi = Math.PI / points;
      const inner = clamp(
        Math.cos(phi) - Math.sin(phi) / Math.tan(angle / 2),
        0.05,
        0.95,
      );
      const g = starGeometry(points, inner, height);
      g.scale(width / 2, 1, depth / 2);
      return g;
    }
    default:
      return new THREE.BoxGeometry(width, height, depth);
  }
}
function material(d) {
  return new THREE.MeshStandardMaterial({
    color: d.color,
    metalness: clamp(Number(d.metallic) || 0, 0, 1),
    roughness: 1 - clamp(Number(d.smoothness) || 0, 0, 1),
    transparent: d.opacity < 1,
    opacity: clamp(Number(d.opacity) || 0, 0, 1),
    depthWrite: d.opacity >= 1,
    side: d.type === "plane" ? THREE.DoubleSide : THREE.FrontSide,
    flatShading: false,
  });
}
const textureLoader = new THREE.TextureLoader();
const textureCache = new Map();
const importCache = new Map();
let renderAssetGeneration = 0;
const importPromises = new Map();
const assetDB = new Promise((resolve, reject) => {
  if (!window.indexedDB) {
    reject(new Error("IndexedDB is unavailable in this browser."));
    return;
  }
  const open = indexedDB.open("dango-3d-assets", 1);
  open.onupgradeneeded = () => {
    if (!open.result.objectStoreNames.contains("files")) {
      open.result.createObjectStore("files");
    }
  };
  open.onsuccess = () => resolve(open.result);
  open.onerror = () => reject(open.error);
});
assetDB.catch(() => {});

async function storeAsset(id, file) {
  const db = await assetDB;
  return new Promise((resolve, reject) => {
    const tx = db.transaction("files", "readwrite");
    tx.objectStore("files").put(file, id);
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
    tx.onabort = () =>
      reject(tx.error || new Error("Asset storage was aborted."));
  });
}

async function deleteAsset(id) {
  const db = await assetDB;
  return new Promise((resolve, reject) => {
    const tx = db.transaction("files", "readwrite");
    tx.objectStore("files").delete(id);
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error || new Error("Asset deletion was aborted."));
  });
}

async function loadAsset(id) {
  const db = await assetDB;
  return new Promise((resolve, reject) => {
    const tx = db.transaction("files");
    const request = tx.objectStore("files").get(id);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function actorsByName(source = state.actors) {
  const result = Object.create(null);
  for (const data of Object.values(source || {})) {
    if (!data?.name) continue;
    // Every caller serializes immediately; copying through JSON here doubled
    // the work and duplicated embedded texture data during every save/undo.
    result[data.name] = data;
  }
  return result;
}

function collectAssetRefs(actors = state.actors) {
  const refs = new Map();
  for (const data of Object.values(actors || {})) {
    for (const model of data?.models || []) {
      for (const object of model.objects || []) {
        const source = object.source;
        if (safeAssetId(source?.assetId)) {
          refs.set(source.assetId, {
            assetId: source.assetId,
            format: source.format || "glb",
          });
        }
      }
    }
  }
  return [...refs.values()];
}

function collectEmbeddedAssetData(actors = state.actors) {
  const dataById = new Map();
  for (const data of Object.values(actors || {})) {
    for (const model of data?.models || []) {
      for (const object of model.objects || []) {
        const source = object.source;
        if (
          safeAssetId(source?.assetId) &&
          typeof source.data === "string" &&
          !dataById.has(source.assetId)
        ) {
          dataById.set(source.assetId, source.data);
        }
      }
    }
  }
  return dataById;
}

function assetFileName(asset) {
  if (!safeAssetId(asset?.assetId)) return null;
  const format = ["glb", "gltf", "obj"].includes(asset.format)
    ? asset.format
    : "glb";
  return `${ASSET_PATH}/${asset.assetId}.${format}`;
}

function dataUrlToBytes(dataUrl) {
  const encoded = String(dataUrl).split(",").at(-1);
  if (!isBase64Payload(encoded)) throw new Error("Invalid base64 model data.");
  return Uint8Array.from(atob(encoded), (character) => character.charCodeAt(0));
}

function bytesToBase64(bytes) {
  let binary = "";
  for (let offset = 0; offset < bytes.length; offset += 8192) {
    binary += String.fromCharCode(...bytes.subarray(offset, offset + 8192));
  }
  return btoa(binary);
}

async function bytesForAsset(assetId, source) {
  if (assetBytes.has(assetId)) return assetBytes.get(assetId);
  if (source?.data) {
    // Inline fallback data already occupies substantial string storage. Decode
    // on demand without retaining a second in-memory copy.
    return dataUrlToBytes(source.data);
  }
  const generation = renderAssetGeneration;
  const stored = await loadAsset(assetId);
  if (!stored) return null;
  const bytes = new Uint8Array(await stored.arrayBuffer());
  if (generation === renderAssetGeneration) assetBytes.set(assetId, bytes);
  return bytes;
}

function normalizeActors(source) {
  const result = Object.create(null);
  for (const [key, value] of Object.entries(source || {})) {
    if (!value || typeof value !== "object") continue;
    const name = safeModelName(value.name, key);
    result[name] = normalizeActor(value, name);
  }
  return result;
}

function projectSignature(projectJSON) {
  return (projectJSON?.targets || [])
    .filter((target) => !target.isStage)
    .map((target) => {
      const costumes = (target.costumes || [])
        .map((costume) => costume.assetId || costume.md5ext || costume.name)
        .join(",");
      return `${target.name || ""}:${costumes}`;
    })
    .sort()
    .join("|");
}

function sceneProjectData() {
  return {
    schemaVersion: 1,
    projectId: state.projectId,
    signature: state.projectSignature,
    coordinates: {
      up: "Y",
      scratchX: "X",
      scratchY: "-Z",
      unitsPerStep: 1 / SCRATCH_UNITS_PER_WORLD_UNIT,
    },
    actors: actorsByName(),
    scenes: state.scenes,
    assets: collectAssetRefs(),
    advancedSettings: captureRuntimeSettings(window.vm),
  };
}

async function hydrateAssetCache() {
  const refs = collectAssetRefs();
  await Promise.all(
    refs.map(async (asset) => {
      try {
        await bytesForAsset(asset.assetId, null);
      } catch (error) {
        console.warn(`Unable to restore 3D asset ${asset.assetId}`, error);
      }
    }),
  );
}

async function initializeProjectState() {
  state.projectId = await projectIdPromise;
  state.storageKey = `${STORAGE_PREFIX}${encodeURIComponent(state.projectId)}`;
  let cached = null;
  let migratedLegacy = false;
  try {
    cached = JSON.parse(localStorage.getItem(state.storageKey) || "null");
  } catch (error) {
    console.warn("Could not read the 3D project cache", error);
  }
  if (!cached) {
    try {
      const legacy = JSON.parse(
        localStorage.getItem(LEGACY_STORAGE_KEY) || "null",
      );
      if (legacy && typeof legacy === "object") {
        cached = { actors: legacy, signature: null };
        migratedLegacy = true;
        console.info("Migrating the previous local 3D model cache.");
      }
    } catch (error) {
      console.warn("Could not migrate the previous 3D model cache", error);
    }
  }
  state.actors = normalizeActors(cached?.actors || {});
  state.scenes = normalizeScenes(cached?.scenes);
  state.projectSignature = cached?.signature || null;
  await hydrateAssetCache();
  if (migratedLegacy) {
    flushSave();
    try {
      localStorage.removeItem(LEGACY_STORAGE_KEY);
    } catch (error) {
      console.warn("Could not remove the migrated 3D cache", error);
    }
  }
  return true;
}

readyPromise = initializeProjectState().catch((error) => {
  console.warn(
    "3D project storage is unavailable; using an empty scene.",
    error,
  );
  state.projectId = state.projectId || "local";
  state.storageKey = `${STORAGE_PREFIX}${encodeURIComponent(state.projectId)}`;
  state.actors = Object.create(null);
  return false;
});

function flushSave() {
  clearTimeout(saveTimer);
  saveTimer = 0;
  clearTimeout(runtimeSaveTimer);
  runtimeSaveTimer = 0;
  clearTimeout(runtimeSaveMaxTimer);
  runtimeSaveMaxTimer = 0;
  if (!state.storageKey) return;
  try {
    localStorage.setItem(
      state.storageKey,
      JSON.stringify({
        schemaVersion: 2,
        signature: state.projectSignature,
        actors: actorsByName(),
        scenes: state.scenes,
      }),
    );
  } catch (error) {
    console.warn("Unable to update the local 3D cache", error);
  }
}

async function restoreProjectScene(sceneData, zip, signature) {
  clearProjectAssetCaches();
  actorRevisions.clear();
  sceneRevision++;
  state.actors = normalizeActors(sceneData.actors || {});
  state.scenes = normalizeScenes(sceneData.scenes);
  state.projectSignature = sceneData.signature || signature || null;
  state.targetTransforms.clear();
  const refs = Array.isArray(sceneData.assets)
    ? sceneData.assets.filter((asset) => safeAssetId(asset?.assetId))
    : collectAssetRefs(state.actors);
  await Promise.all(
    refs.map(async (asset) => {
      try {
        let bytes = assetBytes.get(asset.assetId);
        const path = assetFileName(asset);
        const entry = path ? zip?.file?.(path) : null;
        if (!bytes && entry) bytes = await entry.async("uint8array");
        if (!bytes) bytes = await bytesForAsset(asset.assetId, null);
        if (bytes) {
          const normalizedBytes = new Uint8Array(bytes);
          assetBytes.set(asset.assetId, normalizedBytes);
          await storeAsset(asset.assetId, new Blob([normalizedBytes]));
        }
      } catch (error) {
        console.warn(`Unable to restore 3D asset ${asset.assetId}`, error);
      }
    }),
  );
  flushSave();
}

async function restoreCacheForProject(projectJSON, signature) {
  clearProjectAssetCaches();
  actorRevisions.clear();
  sceneRevision++;
  if (projectLoadedOnce) {
    state.actors = Object.create(null);
    state.scenes = [];
    state.targetTransforms.clear();
  } else if (state.projectSignature && state.projectSignature !== signature) {
    state.actors = Object.create(null);
    state.scenes = [];
  } else if (!state.projectSignature) {
    const names = new Set(
      (projectJSON?.targets || [])
        .filter((target) => !target.isStage)
        .map((target) => target.name),
    );
    const matchingActors = Object.create(null);
    for (const [key, data] of Object.entries(state.actors)) {
      if (names.has(data.name)) matchingActors[key] = data;
    }
    state.actors = matchingActors;
  }
  state.projectSignature = signature || state.projectSignature;
  state.targetTransforms.clear();
  await hydrateAssetCache();
  flushSave();
}

class Dango3DExtension {
  constructor(runtime) {
    this.runtime = runtime;
  }

  getInfo() {
    return {
      id: "dango3d",
      name: "3D",
      color1: "#4c97ff",
      color2: "#4280d7",
      color3: "#3373cc",
      targetTypes: ["sprite"],
      blocks: [
        {
          opcode: "moveSteps3D", blockType: "command", text: "move [STEPS] steps in 3D",
          arguments: { STEPS: { type: "number", defaultValue: 10 } },
        },
        {
          opcode: "turnRight3D", blockType: "command", text: "turn right [DEGREES] degrees",
          arguments: { DEGREES: { type: "number", defaultValue: 15 } },
        },
        {
          opcode: "turnLeft3D", blockType: "command", text: "turn left [DEGREES] degrees",
          arguments: { DEGREES: { type: "number", defaultValue: 15 } },
        },
        {
          opcode: "pointDirection3D", blockType: "command", text: "point direction [DIRECTION] pitch [PITCH]",
          arguments: {
            DIRECTION: { type: "number", defaultValue: 90 },
            PITCH: { type: "number", defaultValue: 0 },
          },
        },
        {
          opcode: "goToPosition3D", blockType: "command", text: "go to x: [X] y: [Y] z: [Z]",
          arguments: {
            X: { type: "number", defaultValue: 0 },
            Y: { type: "number", defaultValue: 0 },
            Z: { type: "number", defaultValue: 0 },
          },
        },
        {
          opcode: "glideToPosition3D", blockType: "command", text: "glide [SECS] secs to x: [X] y: [Y] z: [Z]",
          arguments: {
            SECS: { type: "number", defaultValue: 1 },
            X: { type: "number", defaultValue: 0 },
            Y: { type: "number", defaultValue: 0 },
            Z: { type: "number", defaultValue: 0 },
          },
        },
        ...["X", "Y", "Z"].flatMap(axis => [
          {
            opcode: `change${axis}3D`, blockType: "command", text: `change ${axis.toLowerCase()} by [DELTA]`,
            arguments: { DELTA: { type: "number", defaultValue: 10 } },
          },
          {
            opcode: `set${axis}3D`, blockType: "command", text: `set ${axis.toLowerCase()} to [VALUE]`,
            arguments: { VALUE: { type: "number", defaultValue: 0 } },
          },
          { opcode: `${axis.toLowerCase()}Position3D`, blockType: "reporter", text: `${axis.toLowerCase()} position` },
        ]),
        { opcode: "direction3D", blockType: "reporter", text: "direction" },
        {
          opcode: "gotoXYZ",
          blockType: "command",
          text: "go to x: [X] y: [Y] height: [HEIGHT]",
          arguments: {
            X: { type: "number", defaultValue: 0 },
            Y: { type: "number", defaultValue: 0 },
            HEIGHT: { type: "number", defaultValue: 0 },
          },
        },
        {
          opcode: "setHeight",
          blockType: "command",
          text: "set height to [HEIGHT]",
          arguments: { HEIGHT: { type: "number", defaultValue: 0 } },
        },
        {
          opcode: "changeHeight",
          blockType: "command",
          text: "change height by [DELTA]",
          arguments: { DELTA: { type: "number", defaultValue: 1 } },
        },
        {
          opcode: "height",
          blockType: "reporter",
          text: "height",
        },
        {
          opcode: "setYaw",
          blockType: "command",
          text: "set 3D yaw offset to [ANGLE] degrees",
          arguments: { ANGLE: { type: "number", defaultValue: 0 } },
        },
        {
          opcode: "changeYaw",
          blockType: "command",
          text: "change 3D yaw offset by [DELTA] degrees",
          arguments: { DELTA: { type: "number", defaultValue: 15 } },
        },
        {
          opcode: "yaw",
          blockType: "reporter",
          text: "3D yaw offset",
        },
        {
          opcode: "setPitch",
          blockType: "command",
          text: "set pitch to [ANGLE] degrees",
          arguments: { ANGLE: { type: "number", defaultValue: 0 } },
        },
        {
          opcode: "changePitch",
          blockType: "command",
          text: "change pitch by [DELTA] degrees",
          arguments: { DELTA: { type: "number", defaultValue: 15 } },
        },
        {
          opcode: "pitch",
          blockType: "reporter",
          text: "3D pitch",
        },
        {
          opcode: "setRoll",
          blockType: "command",
          text: "set roll to [ANGLE] degrees",
          arguments: { ANGLE: { type: "number", defaultValue: 0 } },
        },
        {
          opcode: "changeRoll",
          blockType: "command",
          text: "change roll by [DELTA] degrees",
          arguments: { DELTA: { type: "number", defaultValue: 15 } },
        },
        {
          opcode: "roll",
          blockType: "reporter",
          text: "3D roll",
        },
        {
          opcode: "selectModel",
          blockType: "command",
          text: "switch model to [MODEL]",
          arguments: { MODEL: { type: "string", defaultValue: "model1" } },
        },
        {
          opcode: "modelName",
          blockType: "reporter",
          text: "model name",
        },
      ],
    };
  }

  moveSteps3D(args, util) {
    const target = util.target;
    if (!target || target.isStage) return;
    const next = forwardStep3D(target, runtimeTransform(target), args.STEPS);
    setPosition3D(target, next.x, next.y, next.z);
  }

  turnRight3D(args, util) {
    setDirection3D(util.target, Number(util.target?.direction ?? 90) + Number(args.DEGREES));
  }

  turnLeft3D(args, util) {
    setDirection3D(util.target, Number(util.target?.direction ?? 90) - Number(args.DEGREES));
  }

  pointDirection3D(args, util) {
    setDirection3D(util.target, args.DIRECTION);
    setRuntimeTransform(util.target, "pitch", args.PITCH);
  }

  goToPosition3D(args, util) {
    setPosition3D(util.target, args.X, args.Y, args.Z);
  }

  glideToPosition3D(args, util) {
    const target = util.target;
    if (!target || target.isStage) return;
    const frame = util.stackFrame;
    if (!frame.dango3dGlide) {
      const seconds = Math.max(0, Number(args.SECS) || 0);
      frame.dango3dGlide = {
        start: performance.now(),
        duration: seconds * 1000,
        from: [target.x, target.y, positionZ(target)],
        to: [Number(args.X), Number(args.Y), Number(args.Z)],
      };
    }
    const glide = frame.dango3dGlide;
    const fraction = glide.duration ? Math.min(1, (performance.now() - glide.start) / glide.duration) : 1;
    setPosition3D(target, ...glide.from.map((value, index) => value + (glide.to[index] - value) * fraction));
    if (fraction < 1) util.yield();
    else delete frame.dango3dGlide;
  }

  changeX3D(args, util) { setTargetXY3D(util.target, Number(util.target?.x || 0) + Number(args.DELTA), util.target?.y); }
  setX3D(args, util) { setTargetXY3D(util.target, args.VALUE, util.target?.y); }
  xPosition3D(args, util) { return util.target?.x || 0; }
  changeY3D(args, util) { setTargetXY3D(util.target, util.target?.x, Number(util.target?.y || 0) + Number(args.DELTA)); }
  setY3D(args, util) { setTargetXY3D(util.target, util.target?.x, args.VALUE); }
  yPosition3D(args, util) { return util.target?.y || 0; }
  changeZ3D(args, util) { setRuntimeTransform(util.target, "height", Number(args.DELTA) / SCRATCH_UNITS_PER_WORLD_UNIT, true); }
  setZ3D(args, util) { setRuntimeTransform(util.target, "height", Number(args.VALUE) / SCRATCH_UNITS_PER_WORLD_UNIT); }
  zPosition3D(args, util) { return positionZ(util.target); }
  direction3D(args, util) { return util.target?.direction ?? 90; }

  gotoXYZ(args, util) {
    const x = Number(args.X);
    const y = Number(args.Y);
    if (Number.isFinite(x) && Number.isFinite(y)) setTargetXY3D(util.target, x, y);
    setRuntimeTransform(util.target, "height", args.HEIGHT);
  }

  setHeight(args, util) {
    setRuntimeTransform(util.target, "height", args.HEIGHT);
  }

  changeHeight(args, util) {
    setRuntimeTransform(util.target, "height", args.DELTA, true);
  }

  height(args, util) {
    return runtimeTransform(util.target).height;
  }

  setYaw(args, util) {
    setRuntimeTransform(util.target, "yaw", args.ANGLE);
  }

  changeYaw(args, util) {
    setRuntimeTransform(util.target, "yaw", args.DELTA, true);
  }

  yaw(args, util) {
    return runtimeTransform(util.target).yaw;
  }

  setPitch(args, util) {
    setRuntimeTransform(util.target, "pitch", args.ANGLE);
  }

  changePitch(args, util) {
    setRuntimeTransform(util.target, "pitch", args.DELTA, true);
  }

  pitch(args, util) {
    return runtimeTransform(util.target).pitch;
  }

  setRoll(args, util) {
    setRuntimeTransform(util.target, "roll", args.ANGLE);
  }

  changeRoll(args, util) {
    setRuntimeTransform(util.target, "roll", args.DELTA, true);
  }

  roll(args, util) {
    return runtimeTransform(util.target).roll;
  }

  selectModel(args, util) {
    const target = util.target;
    const data = dataForTarget(target);
    if (!data || !target || target.isStage) return;
    const index = data.models.findIndex(model => model.name === String(args.MODEL));
    if (index < 0) return;
    if (target.isOriginal) {
      if (data.active === index) return;
      data.active = index;
      save({ sceneChanged: true, actorName: data.name });
      updateThumbnails();
      if (editor?.root.isConnected && window.vm?.editingTarget?.id === target.id) {
        state.selected = [];
        editor.refresh();
      }
    } else {
      cloneModels.set(target.id, index);
    }
    stage?.invalidate();
  }

  modelName(args, util) {
    const data = dataForTarget(util.target);
    return data?.models[cloneModels.get(util.target?.id) ?? data.active]?.name || "";
  }
}

// Put the 3D blocks in Scratch's native categories. Keep the 2D blocks too:
// they remain useful for older projects and make Motion available while the
// 3D extension palette is refreshing.
window.dango3dToolbox = (motion, looks) => {
  const number = (name, value) => '<value name="' + name + '"><shadow type="math_number"><field name="NUM">' + value + '</field></shadow></value>';
  const block = (opcode, inputs = '') => '<block type="dango3d_' + opcode + '">' + inputs + '</block>';
  const motionBlocks = '<label text="3D movement"></label>' +
    block('moveSteps3D', number('STEPS', 10)) +
    block('turnRight3D', number('DEGREES', 15)) + block('turnLeft3D', number('DEGREES', 15)) +
    block('pointDirection3D', number('DIRECTION', 90) + number('PITCH', 0)) +
    '<sep gap="32"/>' +
    block('goToPosition3D', number('X', 0) + number('Y', 0) + number('Z', 0)) +
    block('glideToPosition3D', number('SECS', 1) + number('X', 0) + number('Y', 0) + number('Z', 0)) +
    '<sep gap="32"/>' +
    ['X', 'Y', 'Z'].map(axis =>
      block(`change${axis}3D`, number('DELTA', 10)) +
      block(`set${axis}3D`, number('VALUE', 0))
    ).join('') +
    '<sep gap="32"/>' +
    block('xPosition3D') + block('yPosition3D') + block('zPosition3D') + block('direction3D') +
    '<label text="3D orientation"></label>' +
    block('setYaw', number('ANGLE', 0)) + block('changeYaw', number('DELTA', 15)) + block('yaw') +
    block('setPitch', number('ANGLE', 0)) + block('changePitch', number('DELTA', 15)) + block('pitch') +
    block('setRoll', number('ANGLE', 0)) + block('changeRoll', number('DELTA', 15)) + block('roll');
  const looksBlocks = '<label text="3D models"></label>' +
    block('selectModel', '<value name="MODEL"><shadow type="text"><field name="TEXT">model1</field></shadow></value>') +
    block('modelName');
  const append = (category, blocks) => category.replace(
    /<\/category>\s*$/,
    '<sep gap="36"/>' + blocks + '</category>',
  );
  return {
    motion: append(motion, motionBlocks),
    looks: append(looks, looksBlocks),
  };
};

function installVmHooks(vm) {
  if (!vm || (typeof vm !== "object" && typeof vm !== "function") || hookedVMs.has(vm)) return;
  hookedVMs.add(vm);

  try {
    const manager = vm.extensionManager;
    if (manager?.addBuiltinExtension && manager?.loadExtensionIdSync) {
      if (!manager.isBuiltinExtension("dango3d")) {
        manager.addBuiltinExtension("dango3d", Dango3DExtension);
      }
      if (!manager.isExtensionLoaded("dango3d")) {
        manager.loadExtensionIdSync("dango3d");
      }
    }
  } catch (error) {
    console.error("Unable to register the 3D blocks", error);
  }

  installRuntimeSettings(vm, () => projectLoading);

  if (typeof vm.toJSON === "function") {
    const originalToJSON = vm.toJSON.bind(vm);
    vm.toJSON = (targetId, serializationOptions) => {
      const serialized = originalToJSON(targetId, serializationOptions);
      if (targetId) return serialized;
      try {
        const projectJSON = JSON.parse(serialized);
        projectJSON[PROJECT_FIELD] = sceneProjectData();
        return JSON.stringify(projectJSON);
      } catch (error) {
        console.error(
          "Unable to serialize the 3D scene with the project",
          error,
        );
        return serialized;
      }
    };
  }

  if (typeof vm.serializeAssets === "function") {
    const originalSerializeAssets = vm.serializeAssets.bind(vm);
    vm.serializeAssets = (targetId) => {
      const files = originalSerializeAssets(targetId);
      if (targetId) return files;
      let embeddedAssetData;
      for (const asset of collectAssetRefs()) {
        let bytes = assetBytes.get(asset.assetId);
        if (!bytes) {
          embeddedAssetData ||= collectEmbeddedAssetData();
          const sourceData = embeddedAssetData.get(asset.assetId);
          if (sourceData) bytes = dataUrlToBytes(sourceData);
        }
        const fileName = assetFileName(asset);
        if (bytes && fileName) {
          files.push({
            fileName,
            fileContent: bytes,
          });
        } else {
          console.warn(
            `3D asset ${asset.assetId} is not ready to be saved yet.`,
          );
        }
      }
      return files;
    };
  }

  if (typeof vm.deserializeProject === "function") {
    const originalDeserializeProject = vm.deserializeProject.bind(vm);
    let loadQueue = Promise.resolve();
    vm.deserializeProject = (projectJSON, zip) => {
      // A second file open must not interleave target installation or asset
      // restoration with the previous load. Failed loads do not poison the queue.
      const load = async () => {
        projectLoading = true;
        clearTimeout(saveTimer);
        clearTimeout(runtimeSaveTimer);
        clearTimeout(runtimeSaveMaxTimer);
        saveTimer = runtimeSaveTimer = runtimeSaveMaxTimer = 0;
        clearTimeout(projectChangeTimer);
        if (editor) clearTimeout(editor.historyTimer);
        try {
          const signature = projectSignature(projectJSON);
          const sceneData = projectJSON?.[PROJECT_FIELD];
          const result = await originalDeserializeProject(projectJSON, zip);
          await readyPromise;
          restoreRuntimeSettings(vm, sceneData?.advancedSettings);
          if (sceneData?.schemaVersion === 1) {
            await restoreProjectScene(sceneData, zip, signature);
          } else {
            await restoreCacheForProject(projectJSON, signature);
          }
          projectLoadedOnce = true;
          state.targetTransforms.clear();
          cloneModels.clear();
          clearThumbnails();
          stage?.markDirty();
          if (editor?.root.isConnected) {
            state.selected = [];
            editor.history = [];
            editor.historyIndex = -1;
            editor.historyPending = false;
            editor.refresh();
            editor.recordHistory(true);
          }
          updateThumbnails();
          return result;
        } finally {
          projectLoading = false;
          requestRender();
          scheduleSyncDOM();
        }
      };
      const pending = loadQueue.then(load);
      loadQueue = pending.catch(() => {});
      return pending;
    };
  }

}

function watchVmAssignment() {
  const descriptor = Object.getOwnPropertyDescriptor(window, "vm");
  if (descriptor && !descriptor.configurable) {
    installVmHooks(window.vm);
    return;
  }
  let current = window.vm;
  Object.defineProperty(window, "vm", {
    configurable: true,
    enumerable: descriptor?.enumerable ?? true,
    get: () => current,
    set: (vm) => {
      current = vm;
      installVmHooks(vm);
      scheduleSyncDOM();
    },
  });
  installVmHooks(current);
}

watchVmAssignment();

function applyMaps(mesh, d) {
  for (const [key, property] of [
    ["texture", "map"],
    ["roughness", "roughnessMap"],
    ["normal", "normalMap"],
    ["metallic", "metalnessMap"],
    ["opacity", "alphaMap"],
  ]) {
    const url = d.maps[key];
    if (!url) continue;
    const cacheKey = `${key}:${url}`;
    let texture = textureCache.get(cacheKey);
    if (!texture) {
      texture = textureLoader.load(
        url,
        () => requestRender(),
        undefined,
        (error) => console.warn(`Unable to load ${key} map`, error),
      );
      texture.colorSpace =
        key === "texture" ? THREE.SRGBColorSpace : THREE.NoColorSpace;
      textureCache.set(cacheKey, texture);
    }
    const materials = Array.isArray(mesh.material)
      ? mesh.material
      : [mesh.material];
    for (const item of materials) {
      if (!item) continue;
      if (item[property] === texture) continue;
      item[property] = texture;
      if (key === "opacity") item.transparent = true;
      item.needsUpdate = true;
    }
  }
}

function parseGlbJSON(bytes) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const magic = 0x46546c67;
  const jsonChunk = 0x4e4f534a;
  if (
    bytes.byteLength < 20 ||
    view.getUint32(0, true) !== magic ||
    view.getUint32(4, true) !== 2 ||
    view.getUint32(8, true) !== bytes.byteLength
  ) {
    throw new Error("Invalid GLB file.");
  }

  let offset = 12;
  while (offset + 8 <= bytes.byteLength) {
    const length = view.getUint32(offset, true);
    const type = view.getUint32(offset + 4, true);
    const dataStart = offset + 8;
    const dataEnd = dataStart + length;
    if (dataEnd > bytes.byteLength) throw new Error("Invalid GLB chunk.");
    if (type === jsonChunk) {
      const text = new TextDecoder().decode(bytes.subarray(dataStart, dataEnd));
      return JSON.parse(text.replace(/\0+$/, "").trim());
    }
    offset = dataEnd;
  }
  throw new Error("GLB file has no JSON chunk.");
}

function validateEmbeddedGltfResources(bytes, format) {
  const document =
    format === "gltf"
      ? JSON.parse(new TextDecoder().decode(bytes))
      : parseGlbJSON(bytes);
  if (!document || typeof document !== "object" || Array.isArray(document)) {
    throw new Error("Invalid glTF document.");
  }

  for (const resource of [
    ...(Array.isArray(document.buffers) ? document.buffers : []),
    ...(Array.isArray(document.images) ? document.images : []),
  ]) {
    if (
      resource?.uri != null &&
      (typeof resource.uri !== "string" || !/^data:/i.test(resource.uri))
    ) {
      throw new Error("External glTF resources are not supported.");
    }
  }
}

function setMaterialProperties(mesh, data) {
  const materials = Array.isArray(mesh.material)
    ? mesh.material
    : [mesh.material];
  for (const item of materials) {
    if (!item) continue;
    item.color?.set(data.color);
    if ("metalness" in item) item.metalness = data.metallic;
    if ("roughness" in item) item.roughness = 1 - data.smoothness;
    item.opacity = data.opacity;
    const transparent = data.opacity < 1 || !!data.maps.opacity;
    if (item.transparent !== transparent) item.needsUpdate = true;
    item.transparent = transparent;
    item.depthWrite = data.opacity >= 1;
  }
}

function loadImportedTemplate(data) {
  if (importCache.has(data.id))
    return Promise.resolve(importCache.get(data.id));
  if (importPromises.has(data.id)) return importPromises.get(data.id);
  const generation = renderAssetGeneration;
  const loader =
    data.source.format === "obj" ? new OBJLoader() : new GLTFLoader();
  const promise = (async () => {
    const bytes = await bytesForAsset(data.source.assetId, data.source);
    if (!bytes) throw new Error(`Missing model asset ${data.source.assetId}`);
    if (data.source.format === "obj") {
      return loader.parse(new TextDecoder().decode(bytes));
    }
    validateEmbeddedGltfResources(bytes, data.source.format);
    const input =
      data.source.format === "gltf"
        ? new TextDecoder().decode(bytes)
        : bytes.buffer.slice(
            bytes.byteOffset,
            bytes.byteOffset + bytes.byteLength,
          );
    return new Promise((resolve, reject) => {
      loader.parse(input, "", (result) => resolve(result.scene), reject);
    });
  })().then(template => {
    if (generation !== renderAssetGeneration) {
      disposeImportedTemplate(template);
      throw new DOMException("The project changed during import", "AbortError");
    }
    return template;
  });
  importPromises.set(data.id, promise);
  promise.then(
    (template) => {
      if (generation === renderAssetGeneration)
        importCache.set(data.id, template);
      if (importPromises.get(data.id) === promise)
        importPromises.delete(data.id);
    },
    () => {
      if (importPromises.get(data.id) === promise)
        importPromises.delete(data.id);
    },
  );
  return promise;
}

function buildObject(raw, allowAssetLoad = true) {
  const data = norm(raw);
  const group = new THREE.Group();
  group.name = data.name;
  group.userData.objectId = data.id;
  group.position.fromArray(data.position);
  group.rotation.fromArray(data.rotation);
  group.scale.fromArray(data.scale);
  if (data.type === "import" && data.source) {
    const done = (template) => {
      const object = cloneSkeleton(template);
      object.traverse((mesh) => {
        if (!mesh.isMesh) return;
        mesh.geometry = mesh.geometry.clone();
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        if (mesh.material) {
          mesh.material = Array.isArray(mesh.material)
            ? mesh.material.map((item) => item?.clone())
            : mesh.material.clone();
          mesh.userData.d3SourceMaterial = mesh.material;
          if (data.materialOverride) setMaterialProperties(mesh, data);
        } else {
          mesh.material = material(data);
        }
        applyMaps(mesh, data);
      });
      object.position.fromArray(data.meshPosition);
      object.rotation.fromArray(data.meshRotation);
      object.scale.fromArray(data.meshScale);
      object.userData.d3ModelContent = true;
      group.add(object);
      if (editor?.nodes.get(data.id) === group) {
        editor.updateGizmo();
        editor.applyView();
      }
      requestRender();
    };
    if (importCache.has(data.id)) {
      done(importCache.get(data.id));
      return group;
    }
    if (allowAssetLoad) {
      loadImportedTemplate(data).then(
        (template) => {
          if (!group.parent || group.userData.d3Disposed) return;
          done(template);
          clearThumbnails();
          setTimeout(() => {
            updateThumbnails();
            if (editor?.root.isConnected) editor.updateUI();
          }, 0);
          if (editor?.selectedData()[0]?.id === data.id)
            setTimeout(() => editor?.focusModel(), 0);
        },
        (error) => { if (error.name !== "AbortError") console.error("Model import failed", error); },
      );
    }
  } else if (data.type !== "empty" && data.type !== "import") {
    const mesh = new THREE.Mesh(geometry(data), material(data));
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    mesh.position.fromArray(data.meshPosition);
    mesh.rotation.fromArray(data.meshRotation);
    mesh.scale.fromArray(data.meshScale);
    applyMaps(mesh, data);
    group.add(mesh);
  }
  return group;
}
let editor;
let stage;
let renderPending = false;

window.dango3dStageCapture = () => {
  try {
    return stage?.captureFrame() || null;
  } catch (error) {
    console.warn("Unable to capture the 3D stage", error);
    return null;
  }
};

function disposeGroup(group) {
  group.traverse((object) => {
    object.userData.d3Disposed = true;
    object.geometry?.dispose();
    if (!object.material) return;
    const materials = new Set(
      Array.isArray(object.material) ? object.material : [object.material],
    );
    const sourceMaterials = object.userData.d3SourceMaterial;
    for (const item of Array.isArray(sourceMaterials)
      ? sourceMaterials
      : [sourceMaterials]) {
      if (item) materials.add(item);
    }
    for (const item of materials) item?.dispose();
  });
}

function disposeImportedTemplate(template) {
  const textures = new Set();
  template.traverse(object => {
    const materials = Array.isArray(object.material) ? object.material : [object.material];
    for (const item of materials) {
      if (item) for (const value of Object.values(item)) if (value?.isTexture) textures.add(value);
    }
  });
  disposeGroup(template);
  for (const texture of textures) texture.dispose();
}

function clearProjectAssetCaches() {
  renderAssetGeneration++;
  for (const texture of textureCache.values()) texture.dispose();
  for (const template of importCache.values()) disposeImportedTemplate(template);
  textureCache.clear();
  importCache.clear();
  importPromises.clear();
  assetBytes.clear();
}

function requestRender() {
  if (renderPending) return;
  renderPending = true;
  requestAnimationFrame(() => {
    renderPending = false;
    stage?.invalidate();
    if (editor?.panel.classList.contains("d3-model-active")) editor.render();
  });
}

class Stage3D {
  constructor(host) {
    this.host = host;
    this.canvas = document.createElement("canvas");
    this.canvas.className = "d3-stage-canvas";
    this.canvas.setAttribute("aria-label", "3D stage");
    host.append(this.canvas);
    this.badge = document.createElement("div");
    this.badge.className = "d3-stage-badge";
    this.badge.setAttribute("aria-live", "polite");
    host.append(this.badge);
    this.renderer = makeRenderer(this.canvas);
    this.scene = makeScene(false);
    this.sceneKey = "";
    this.skyTexture = null;
    this.skyTextureURL = null;
    this.thumbnailCanvas = document.createElement("canvas");
    this.thumbnailCanvas.width = 96;
    this.thumbnailCanvas.height = 72;
    this.thumbnailRenderer = null;
    this.thumbnailScene = new THREE.Scene();
    this.thumbnailScene.environment = envTexture;
    this.thumbnailScene.add(new THREE.HemisphereLight(0xffffff, 0x858080, 2.8));
    const thumbnailLight = new THREE.DirectionalLight(0xffffff, 3);
    thumbnailLight.position.set(3, 5, 4);
    this.thumbnailScene.add(thumbnailLight);
    this.thumbnailCamera = new THREE.PerspectiveCamera(38, 4 / 3, 0.1, 100);
    this.thumbnailCamera.position.set(3, 2.5, 4);
    this.thumbnailCamera.lookAt(0, 0.6, 0);
    this.camera = new THREE.PerspectiveCamera(42, 4 / 3, 0.1, 200);
    this.camera.position.set(5, 3.4, 7.2);
    this.camera.lookAt(0, 1, 0);
    this.objects = new THREE.Group();
    this.objects.name = "runtime actors";
    this.scene.add(this.objects);
    this.entries = new Map();
    this.allDirty = true;
    this.dirtyActorNames = new Set();
    this.raf = 0;
    this.running = false;
    this.disposed = false;
    this.pixelRatio = 0;
    this.width = 0;
    this.height = 0;
    this.frame = this.frame.bind(this);
    this.onVisibilityChange = () => {
      if (document.hidden) this.cancelFrame();
      else this.invalidate();
    };
    this.vm = null;
    this.runtime = null;
    this.runtimeBridge = new Runtime3DBridge({
      onStart: () => this.start(),
      onStop: () => this.stop(),
      onTick: () => this.invalidate(false),
      onChange: () => this.invalidate(false),
    });
    this.bindVM(window.vm);
    document.addEventListener("visibilitychange", this.onVisibilityChange);
    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(host);
    window.addEventListener("resize", (this.onResize = () => this.resize()));
    this.onContextLost = (event) => {
      event.preventDefault();
      this.contextLost = true;
      this.badge.textContent = "3D renderer unavailable";
    };
    this.onContextRestored = () => {
      this.contextLost = false;
      this.sceneKey = "";
      this.invalidate();
    };
    this.canvas.addEventListener("webglcontextlost", this.onContextLost);
    this.canvas.addEventListener(
      "webglcontextrestored",
      this.onContextRestored,
    );
    this.resize();
    this.invalidate();
  }

  bindVM(vm) {
    const runtime = vm?.runtime || null;
    if (this.vm === vm && this.runtime === runtime) return false;

    this.runtimeBridge.bind(vm);
    this.vm = this.runtimeBridge.vm;
    this.runtime = this.runtimeBridge.runtime;
    state.targetTransforms.clear();

    this.allDirty = true;
    this.dirtyActorNames.clear();
    if ((this.runtime?._nonMonitorThreadCount || 0) > 0) this.start();
    else this.invalidate();
    return true;
  }

  markDirty(actorName = null) {
    if (actorName) this.dirtyActorNames.add(actorName);
    else this.allDirty = true;
    this.invalidate();
  }

  sync() {
    this.invalidate(false);
  }

  resize() {
    if (this.disposed) return;
    const rect = this.host.getBoundingClientRect();
    const width = Math.round(rect.width);
    const height = Math.round(rect.height);
    if (width < 1 || height < 1) return;
    const pixelRatio = Math.min(window.devicePixelRatio || 1, 1.5);
    if (
      width === this.width &&
      height === this.height &&
      pixelRatio === this.pixelRatio
    )
      return;
    this.width = width;
    this.height = height;
    if (this.pixelRatio !== pixelRatio) this.renderer.setPixelRatio(pixelRatio);
    this.pixelRatio = pixelRatio;
    this.renderer.setSize(width, height, false);
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.invalidate();
  }

  start() {
    this.running = true;
    this.invalidate();
  }

  stop() {
    this.running = false;
    this.invalidate();
  }

  cancelFrame() {
    if (!this.raf) return;
    cancelAnimationFrame(this.raf);
    this.raf = 0;
  }

  invalidate(forceRender = true) {
    if (this.disposed) return;
    if (forceRender) this.needsRender = true;
    if (document.hidden || this.contextLost || projectLoading || this.raf) return;
    this.raf = requestAnimationFrame(this.frame);
  }

  frame() {
    this.raf = 0;
    if (this.disposed || document.hidden || this.contextLost || projectLoading) return;
    const environmentChanged = this.applySceneSettings();
    const changed = this.syncScene();
    if (changed || environmentChanged || this.needsRender) {
      this.renderer.render(this.scene, this.camera);
      this.needsRender = false;
    }
  }

  captureFrame() {
    if (this.disposed || this.contextLost || projectLoading) return null;
    this.applySceneSettings();
    this.syncScene();
    this.renderer.render(this.scene, this.camera);
    this.needsRender = false;
    return this.canvas.toDataURL("image/png");
  }

  applySceneSettings() {
    const stageTarget = this.vm?.runtime?.getTargetForStage?.();
    if (!stageTarget) return false;
    const index = stageTarget.currentCostume || 0;
    const costumes = stageTarget.getCostumes();
    const key = `${index}:${costumes.length}:${costumes[index]?.name}:${sceneRevision}`;
    if (this.sceneKey === key && this.sceneTarget === stageTarget) return false;
    this.sceneKey = key;
    this.sceneTarget = stageTarget;
    reconcileScenes();
    const settings = sceneSettings(index);
    this.badge.textContent = `SCENE ${index + 1}  /  ${costumes[index]?.name || "Scene"}`;
    const sky = this.scene.getObjectByName("3D background");
    if (this.skyTexture && (settings.skyMode !== "texture" || settings.skyTexture !== this.skyTextureURL)) {
      this.skyTexture.dispose(); this.skyTexture = null; this.skyTextureURL = null;
    }
    sky.visible = settings.skyMode === "gradient" || (settings.skyMode === "texture" && !settings.skyTexture);
    sky.material.uniforms.uSkyColor.value.set(settings.skyColor).convertLinearToSRGB();
    this.scene.background = null;
    this.scene.environment = envTexture;
    if (settings.skyMode === "color") this.scene.background = new THREE.Color(settings.skyColor);
    if (settings.skyMode === "texture" && settings.skyTexture) {
      if (!this.skyTexture) {
        this.skyTextureURL = settings.skyTexture;
        this.skyTexture = textureLoader.load(settings.skyTexture, () => {
          if (this.skyTextureURL === settings.skyTexture) this.invalidate();
        });
        this.skyTexture.mapping = THREE.EquirectangularReflectionMapping;
        this.skyTexture.colorSpace = THREE.SRGBColorSpace;
      }
      this.scene.background = this.skyTexture;
      this.scene.environment = this.skyTexture;
    }
    this.scene.fog = settings.fogEnabled
      ? new THREE.FogExp2(settings.fogColor, Number(settings.fogDensity)) : null;
    this.renderer.toneMappingExposure = Number(settings.exposure);
    this.renderer.shadowMap.enabled = !!settings.shadows;
    this.canvas.style.filter = `brightness(${settings.brightness}) contrast(${settings.contrast}) saturate(${settings.saturation})`;
    const floor = this.scene.getObjectByName("3D ground");
    floor.material.color.set(settings.groundColor);
    floor.receiveShadow = !!settings.shadows;
    const ambient = this.scene.children.find((item) => item.isHemisphereLight);
    const sun = this.scene.children.find((item) => item.isDirectionalLight);
    if (ambient) ambient.intensity = Number(settings.ambient);
    if (sun) { sun.intensity = Number(settings.sun); sun.castShadow = !!settings.shadows; }
    if (sceneEditor?.panel.classList.contains("d3-scene-active")) sceneEditor.sync();
    return true;
  }

  rebuildEntries() {
    for (const entry of this.entries.values()) {
      this.objects.remove(entry.group);
      disposeGroup(entry.group);
    }
    this.entries.clear();
  }

  createEntry(model) {
    const group = new THREE.Group();
    group.name = "3D actor model";
    const nodes = new Map();
    for (const object of model.objects) {
      nodes.set(object.id, buildObject(object));
    }
    for (const object of model.objects) {
      const node = nodes.get(object.id);
      (nodes.get(object.parent) || group).add(node);
    }
    this.objects.add(group);
    return { group, nodes, modelId: model.id, lastRevision: -1 };
  }

  updateEntry(target, data, model, entry) {
    const transform = runtimeTransform(target, data);
    const pose = scratchTargetPose(target, transform);
    const {
      x,
      y,
      direction,
      size,
      visible,
      height,
      yaw,
      pitch,
      roll,
    } = pose;
    const transformChanged = entry.x !== x || entry.y !== y ||
      entry.direction !== direction || entry.size !== size || entry.visible !== visible ||
      entry.height !== height || entry.yaw !== yaw ||
      entry.pitch !== pitch || entry.roll !== roll;
    const dataRevision = actorRevisions.get(data?.name) || 0;
    const dataChanged = entry.lastRevision !== dataRevision;
    if (!transformChanged && !dataChanged) return false;

    if (transformChanged) {
      entry.group.position.fromArray(pose.position);
      entry.group.rotation.order = "YZX";
      entry.group.rotation.fromArray(pose.rotation);
      entry.group.scale.setScalar(pose.scale);
      entry.group.visible = visible;
      entry.x = x;
      entry.y = y;
      entry.direction = direction;
      entry.size = size;
      entry.visible = visible;
      entry.height = height;
      entry.yaw = yaw;
      entry.pitch = pitch;
      entry.roll = roll;
    }

    if (dataChanged)
      for (const object of model.objects) {
        const node = entry.nodes.get(object.id);
        if (!node) continue;
        node.name = object.name;
        node.position.fromArray(object.position);
        node.rotation.fromArray(object.rotation);
        node.scale.fromArray(object.scale);
        const modelContent = node.children.find(child => child.isMesh || child.userData.d3ModelContent);
        if (modelContent) {
          modelContent.position.fromArray(object.meshPosition);
          modelContent.rotation.fromArray(object.meshRotation);
          modelContent.scale.fromArray(object.meshScale);
        }
        node.traverse((child) => {
          if (!child.isMesh || !child.material) return;
          let owner = child; while (owner && !owner.userData.objectId) owner = owner.parent;
          if (owner?.userData.objectId !== object.id) return;
          if (object.type === "import" && !object.materialOverride) {
            applyMaps(child, object);
            return;
          }
          setMaterialProperties(child, object);
          applyMaps(child, object);
        });
      }
    entry.lastRevision = dataRevision;
    return true;
  }

  syncScene() {
    const vm = this.vm;
    if (!vm?.runtime?.targets) return false;
    let changed = false;
    if (this.allDirty) {
      this.rebuildEntries();
      this.allDirty = false;
      this.dirtyActorNames.clear();
      changed = true;
    }
    const seen = new Set();
    const frameId = this.syncVersion = (this.syncVersion || 0) + 1;
    for (const target of vm.runtime.targets) {
      if (target.isStage) continue;
      seen.add(target.id);
      const data = dataForTarget(target);
      const model = data?.models?.[target.isOriginal ? data.active : (cloneModels.get(target.id) ?? data.active)];
      if (!model) continue;
      let entry = this.entries.get(target.id);
      const actorDirty = this.dirtyActorNames.has(data?.name);
      if (!entry || entry.modelId !== model.id || actorDirty) {
        if (entry) {
          this.objects.remove(entry.group);
          disposeGroup(entry.group);
        }
        entry = this.createEntry(model);
        this.entries.set(target.id, entry);
        changed = true;
      }
      entry.lastSeenFrame = frameId;
      if (this.updateEntry(target, data, model, entry)) changed = true;
    }
    for (const targetId of state.targetTransforms.keys()) {
      if (!seen.has(targetId)) state.targetTransforms.delete(targetId);
    }
    for (const targetId of cloneModels.keys()) {
      if (!seen.has(targetId)) cloneModels.delete(targetId);
    }
    for (const [targetId, entry] of this.entries) {
      if (entry.lastSeenFrame === frameId) continue;
      this.objects.remove(entry.group);
      disposeGroup(entry.group);
      this.entries.delete(targetId);
      state.targetTransforms.delete(targetId);
      changed = true;
    }
    this.dirtyActorNames.clear();
    return changed;
  }

  renderThumbnail(model) {
    if (!this.thumbnailRenderer) {
      this.thumbnailRenderer = makeRenderer(this.thumbnailCanvas, false, true);
      this.thumbnailRenderer.setSize(96, 72, false);
      this.thumbnailRenderer.setClearColor(0xffffff, 0);
      this.thumbnailRenderer.shadowMap.enabled = false;
    }
    const old = this.thumbnailScene.getObjectByName("thumbnail-model");
    if (old) {
      this.thumbnailScene.remove(old);
      disposeGroup(old);
    }
    const group = new THREE.Group();
    group.name = "thumbnail-model";
    const nodes = new Map();
    for (const object of model.objects) {
      nodes.set(object.id, buildObject(object, false));
    }
    for (const object of model.objects) {
      (nodes.get(object.parent) || group).add(nodes.get(object.id));
    }
    this.thumbnailScene.add(group);
    const bounds = new THREE.Box3().setFromObject(group);
    if (!bounds.isEmpty()) {
      const center = bounds.getCenter(new THREE.Vector3());
      const size = bounds.getSize(new THREE.Vector3());
      const distance = Math.max(2, size.length() * 1.5);
      this.thumbnailCamera.position
        .copy(center)
        .add(
          new THREE.Vector3(0.65, 0.5, 0.85)
            .normalize()
            .multiplyScalar(distance),
        );
      this.thumbnailCamera.near = Math.max(0.01, distance / 100);
      this.thumbnailCamera.far = Math.max(100, distance * 10);
      this.thumbnailCamera.lookAt(center);
      this.thumbnailCamera.updateProjectionMatrix();
    }
    try {
      this.thumbnailRenderer.render(this.thumbnailScene, this.thumbnailCamera);
      return this.thumbnailCanvas.toDataURL("image/png");
    } finally {
      this.thumbnailScene.remove(group);
      disposeGroup(group);
    }
  }

  dispose() {
    if (this.disposed) return;
    this.disposed = true;
    this.cancelFrame();
    this.resizeObserver.disconnect();
    window.removeEventListener("resize", this.onResize);
    document.removeEventListener("visibilitychange", this.onVisibilityChange);
    this.runtimeBridge.detach();
    this.canvas.removeEventListener("webglcontextlost", this.onContextLost);
    this.canvas.removeEventListener(
      "webglcontextrestored",
      this.onContextRestored,
    );
    this.rebuildEntries();
    this.skyTexture?.dispose();
    this.thumbnailRenderer?.dispose();
    this.thumbnailRenderer?.forceContextLoss?.();
    this.renderer.dispose();
    this.renderer.forceContextLoss?.();
    this.canvas.remove();
    this.badge.remove();
  }
}
class SceneEditor {
  constructor(panel) {
    this.panel = panel;
    this.root = document.createElement("div");
    this.root.className = "d3-editor d3-scene-editor";
    panel.append(this.root);
    this.category = "sky";
    this.key = "";
    this.root.addEventListener("click", (event) => this.click(event));
    this.root.addEventListener("input", (event) => this.change(event));
    this.root.addEventListener("change", (event) => this.change(event));
    this.sync();
  }
  get target() { return window.vm?.runtime?.getTargetForStage?.(); }
  get index() { return this.target?.currentCostume || 0; }
  sync(force = false) {
    const target = this.target;
    if (!target) return;
    reconcileScenes();
    const key = `${this.index}:${this.category}:${target.getCostumes().map((item) => item.name).join("|")}`;
    if (!force && key === this.key) return;
    this.key = key;
    this.render();
  }
  render() {
    const target = this.target;
    const index = this.index;
    const settings = sceneSettings(index);
    const costumes = target.getCostumes();
    const color = (label, key) => `<label class="d3-scene-field"><span>${label}</span><input type="color" data-scene-property="${key}" value="${settings[key]}"></label>`;
    const range = (label, key, min, max, step) => `<label class="d3-scene-field"><span>${label} <output data-scene-output="${key}">${settings[key]}</output></span><input type="range" data-scene-property="${key}" min="${min}" max="${max}" step="${step}" value="${settings[key]}"></label>`;
    const check = (label, key) => `<label class="d3-scene-field d3-scene-check"><span>${label}</span><input type="checkbox" data-scene-property="${key}" ${settings[key] ? "checked" : ""}></label>`;
    const sections = {
      sky: `<h2>Skybox</h2><label class="d3-scene-field"><span>Type</span><select data-scene-property="skyMode"><option value="gradient" ${settings.skyMode === "gradient" ? "selected" : ""}>Sunset gradient</option><option value="color" ${settings.skyMode === "color" ? "selected" : ""}>Solid color</option><option value="texture" ${settings.skyMode === "texture" ? "selected" : ""}>Image texture</option></select></label>${color("Color", "skyColor")}<div class="d3-scene-texture"><span>Texture</span><label class="d3-scene-upload">${settings.skyTexture ? "Replace image" : "+ Add image"}<input type="file" accept="image/png,image/jpeg,image/webp" data-scene-texture></label>${settings.skyTexture ? '<button data-scene-action="remove-texture">Remove</button>' : ""}</div>${settings.skyTexture ? `<img class="d3-scene-preview" src="${settings.skyTexture}" alt="Sky texture preview">` : ""}`,
      fog: `<h2>Fog</h2>${check("Enable fog", "fogEnabled")}${color("Color", "fogColor")}${range("Density", "fogDensity", 0, 0.1, 0.001)}`,
      effects: `<h2>Post Effects</h2>${range("Exposure", "exposure", 0.25, 3, 0.05)}${range("Brightness", "brightness", 0.5, 1.5, 0.01)}${range("Contrast", "contrast", 0.5, 1.5, 0.01)}${range("Saturation", "saturation", 0, 2, 0.01)}`,
      extra: `<h2>Extra</h2>${check("Shadows", "shadows")}${color("Ground color", "groundColor")}${range("Ambient light", "ambient", 0, 4, 0.1)}${range("Sun light", "sun", 0, 6, 0.1)}`,
    };
    this.root.innerHTML = `
      <aside class="d3-assets d3-scene-assets" aria-label="Scenes">
        <div class="d3-scene-list-title">Scenes <span>${costumes.length}</span></div>
        <div class="d3-model-list" role="list" aria-label="Scenes">
          ${costumes.map((costume, i) => `<button role="listitem" data-scene-index="${i}" class="${i === index ? "active" : ""}" aria-label="Scene ${i + 1}: ${escapeHTML(costume.name)}" aria-current="${i === index ? "true" : "false"}" title="${escapeHTML(costume.name)}"><span class="d3-asset-thumb"><span class="d3-asset-index">${i + 1}</span><span class="d3-scene-tile" style="background:${sceneSettings(i).skyColor}">◈</span></span><span class="d3-asset-meta"><span class="d3-asset-name">${escapeHTML(costume.name)}</span></span></button>`).join("")}
        </div>
        <button class="d3-add-fab" data-scene-action="add" title="Duplicate scene" aria-label="Duplicate scene">+</button>
      </aside>
      <main class="d3-workspace">
        <header class="d3-scene-header">
          <label class="d3-scene-name-group"><span>Scene name</span><input class="d3-scene-name" type="text" maxlength="256" aria-label="Scene name" value="${escapeHTML(costumes[index]?.name || "Scene")}"></label>
          <button class="d3-scene-delete" data-scene-action="delete" ${costumes.length <= 1 ? "disabled" : ""} title="Delete scene">Delete scene</button>
        </header>
        <div class="d3-scene-body">
          <nav class="d3-scene-nav" aria-label="Scene settings">${[["sky","Skybox","◩"],["fog","Fog","◌"],["effects","Post Effects","✦"],["extra","Extra","⚙"]].map(([id,label,icon]) => `<button data-scene-category="${id}" class="${this.category === id ? "active" : ""}" aria-current="${this.category === id ? "page" : "false"}"><span aria-hidden="true">${icon}</span>${label}</button>`).join("")}</nav>
          <section class="d3-scene-controls">${sections[this.category]}</section>
        </div>
      </main>`;
  }
  async click(event) {
    const indexButton = event.target.closest("[data-scene-index]");
    if (indexButton) { this.target.setCostume(Number(indexButton.dataset.sceneIndex)); stage?.invalidate(); this.sync(true); return; }
    const category = event.target.closest("[data-scene-category]");
    if (category) { this.category = category.dataset.sceneCategory; this.sync(true); return; }
    const action = event.target.closest("[data-scene-action]")?.dataset.sceneAction;
    if (action === "add") {
      const index = this.index;
      const copy = structuredClone(sceneSettings(index));
      try {
        await window.vm.duplicateCostume(index);
        reconcileScenes();
        state.scenes[index + 1].settings = copy;
        save({ recordHistory: false });
        stage?.invalidate(); this.sync(true);
      } catch (error) { console.error("Could not duplicate scene", error); }
    } else if (action === "delete" && this.target.getCostumes().length > 1) {
      const index = this.index;
      window.vm.deleteCostume(index);
      state.scenes.splice(index, 1);
      reconcileScenes();
      save({ recordHistory: false }); stage?.invalidate(); this.sync(true);
    } else if (action === "remove-texture") {
      sceneSettings(this.index).skyTexture = null;
      if (sceneSettings(this.index).skyMode === "texture") sceneSettings(this.index).skyMode = "gradient";
      save({ recordHistory: false }); stage?.invalidate(); this.sync(true);
    }
  }
  async change(event) {
    const input = event.target;
    if (input.classList.contains("d3-scene-name") && event.type === "change") {
      const value = input.value.trim().slice(0, 256) || "Scene";
      window.vm.renameCostume(this.index, value);
      state.scenes[this.index].name = this.target.getCostumes()[this.index].name;
      save({ recordHistory: false }); this.sync(true);
      return;
    }
    if (input.matches("[data-scene-texture]")) {
      if (event.type !== "change" || !input.files?.[0]) return;
      const sceneTarget = this.target;
      const sceneIndex = this.index;
      const settings = sceneSettings(sceneIndex);
      const generation = renderAssetGeneration;
      let bitmap;
      try {
        bitmap = await createImageBitmap(input.files[0], { imageOrientation: "flipY" });
        let dataURL;
        try { dataURL = resizedImageDataURL(bitmap); }
        catch { dataURL = await fileDataURL(input.files[0]); }
        if (
          generation !== renderAssetGeneration ||
          this.target !== sceneTarget ||
          !state.scenes.some((scene) => scene.settings === settings)
        ) return;
        settings.skyTexture = dataURL;
        settings.skyMode = "texture";
        save({ recordHistory: false });
        stage?.invalidate();
        if (this.index === sceneIndex) this.sync(true);
      } catch (error) { console.error("Could not load scene texture", error); }
      finally { bitmap?.close?.(); }
      return;
    }
    const key = input.dataset.sceneProperty;
    if (!key) return;
    if (input.tagName === "SELECT" ? event.type !== "change" : event.type !== "input") return;
    const settings = sceneSettings(this.index);
    settings[key] = input.type === "checkbox" ? input.checked : input.type === "range" ? Number(input.value) : input.value;
    const output = $(`[data-scene-output="${key}"]`, this.root);
    if (output) output.textContent = input.value;
    if (key === "skyColor") {
      const tile = $(`.d3-model-list [data-scene-index="${this.index}"] .d3-scene-tile`, this.root);
      if (tile) tile.style.background = input.value;
    }
    if (key === "skyMode") this.sync(true);
    save({ recordHistory: false }); stage?.invalidate();
  }
  dispose() { this.root.remove(); if (sceneEditor === this) sceneEditor = null; }
}
class ModelEditor {
  constructor(panel) {
    this.panel = panel;
    this.root = document.createElement("div");
    this.root.className = "d3-editor";
    panel.append(this.root);
    this.root.innerHTML = editorMarkup(uiIcon);
    this.shapeDefaults = {};
    this.lastShape = "cube";
    this.snap = true;
    this.canvas = $(".d3-canvas", this.root);
    this.renderer = makeRenderer(this.canvas);
    this.renderer.toneMappingExposure = state.exposure;
    this.scene = makeScene(true);
    this.camera = new THREE.PerspectiveCamera(45, 1, 0.1, 200);
    this.camera.position.set(5, 4.4, 7);
    this.camera.lookAt(0, 1, 0);
    this.controls = new OrbitControls(this.camera, this.canvas);
    this.controls.mouseButtons = {
      LEFT: undefined,
      MIDDLE: THREE.MOUSE.PAN,
      RIGHT: THREE.MOUSE.ROTATE,
    };
    this.controls.target.set(0, 1, 0);
    this.controls.touches = { ONE: THREE.TOUCH.ROTATE, TWO: THREE.TOUCH.DOLLY_PAN };
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.1;
    this.controls.addEventListener("change", requestRender);
    this.content = new THREE.Group();
    this.scene.add(this.content);
    this.nodes = new Map();
    this.selectionHelpers = new Map();
    this.history = [];
    this.historyIndex = -1;
    this.historyTimer = 0;
    this.clipboard = null;
    this.wireframe = false;
    this.wireframeOverlay = new WireframeOverlay();
    this.shadows = true;
    this.ray = new THREE.Raycaster();
    this.pointer = new THREE.Vector2();
    this.floor = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
    this.transformProxy = new THREE.Object3D();
    this.scene.add(this.transformProxy);
    this.gizmos = ["translate", "rotate", "scale"].map((mode, index) => {
      const control = new TransformControls(this.camera, this.canvas);
      control.setMode(mode);
      control.setSize([1, 1.3, .7][index]);
      this.scene.add(control.getHelper());
      control.addEventListener("change", requestRender);
      control.addEventListener("dragging-changed", e => {
        this.controls.enabled = !e.value;
        this.gizmoDragging = e.value;
        if (e.value) {
          this.clickStart = null;
          this.recordHistory(true);
          this.captureTransform();
          for (const other of this.gizmos) if (other !== control) other.enabled = false;
        } else {
          this.persistObjects();
          this.updateGizmo(); this.updateUI();
        }
      });
      control.addEventListener("objectChange", () => {
        this.applyTransform();
        requestRender();
      });
      return control;
    });
    this.gizmo = this.gizmos[0];
    this.touchPointers = new Set();
    this.addTools();
    this.bind();
    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(this.canvas.parentElement);
    this.resize();
    if (!state.selected.length && activeModel()?.objects.length)
      state.selected = [activeModel().objects[0].id];
    this.refresh();
    this.recordHistory(true);
  }
  addTools() {
    const paths = {
      cube: '<path d="m12 3 8 4.5v9L12 21l-8-4.5v-9zM4 7.5l8 5 8-5M12 12.5V21"/>',
      sphere:
        '<circle cx="12" cy="12" r="9"/><ellipse cx="12" cy="12" rx="4" ry="9"/><path d="M3 12h18"/>',
      cylinder:
        '<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 4 16 4 16 0V5M4 19c0-4 16-4 16 0"/>',
      cone: '<path d="M12 3 4 19c0 3 16 3 16 0z"/><path d="M4 19c0-3 16-3 16 0"/>',
      plane: '<path d="m3 16 7-9 11 1-7 9zM3 16l11 1"/>',
      torus:
        '<ellipse cx="12" cy="12" rx="10" ry="7"/><ellipse cx="12" cy="12" rx="4" ry="2.5"/>',
      star: '<path d="m12 2 2.8 6.7 7.2.6-5.5 4.7 1.7 7-6.2-3.7L5.8 21l1.7-7L2 9.3l7.2-.6z"/>',
    };
    $(".d3-tools", this.root).innerHTML = `
      <button data-tool="select" title="Select" aria-label="Select">${uiIcon("select", 24)}</button>
      <button data-tool="gizmo" title="Transform" aria-label="Transform">${uiIcon("gizmo", 32)}</button>
      <button class="d3-add-mesh" data-action="mesh-menu" title="Shapes" aria-label="Shapes">${uiIcon("shapes", 32)}</button>`;
    $(".d3-shape-grid", this.root).innerHTML = Object.entries(paths).map(([id, path]) =>
      `<button data-tool="${id}" title="${capitalize(id)}"><svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.7">${path}</svg><span>${capitalize(id)}</span></button>`).join("");
  }
  bind() {
    const root = this.root;
    root.addEventListener("click", (e) => {
      const tool = e.target.closest("[data-tool]");
      if (tool) {
        state.tool = tool.dataset.tool;
        if (!["select", "gizmo"].includes(state.tool)) { this.lastShape = state.tool; state.selected = []; }
        this.closePopovers();
        $(".d3-mesh-menu", root).hidden = true;
        this.updateGizmo();
        this.updateUI();
        return;
      }
      const remove = e.target.closest("[data-remove-map]");
      if (remove) {
        const object = this.propertyTarget();
        if (object) { delete object.maps[remove.dataset.removeMap]; if (object.id && this.nodes.has(object.id)) { save({sceneChanged:true, actorName:actor()?.name}); this.refresh(); } else this.updateUI(); }
        return;
      }
      const action = e.target.closest("[data-action]");
      if (action) {
        this.action(action.dataset.action);
        return;
      }
      const pop = e.target.closest("[data-pop]");
      if (pop) {
        this.togglePopover(pop);
        return;
      }
      const model = e.target.closest("[data-model]");
      if (model) {
        const currentActor = actor();
        currentActor.active = Number(model.dataset.model);
        state.selected = [];
        save({ sceneChanged: true, actorName: currentActor.name });
        this.refresh();
        return;
      }
      const tree = e.target.closest("[data-object]");
      if (tree) {
        this.select(tree.dataset.object, e.shiftKey);
        return;
      }
      if (e.target.closest(".d3-hierarchy-toggle")) {
        state.showHierarchy = !state.showHierarchy;
        this.updateUI();
      }
    });
    $(".d3-import", root).addEventListener("change", (e) => {
      if (e.target.files[0]) this.importModel(e.target.files[0]).catch(error => { console.error(error); this.status("This model could not be loaded. Use GLB, embedded glTF, or OBJ."); });
      e.target.value = "";
    });
    root.addEventListener("pointerdown", (e) => {
      if (!e.target.closest(".d3-add-wrap")) $(".d3-add-menu", root).hidden = true;
      if (!e.target.closest(".d3-popup, [data-pop]")) this.closePopovers();
    });
    root.addEventListener("input", (e) => { if (e.target.type !== "number") this.propertyChange(e.target); });
    root.addEventListener("change", (e) => {
      if (e.target.matches(".d3-view-mode")) {
        state.view = e.target.value; this.applyView();
      } else if (e.target.matches(".d3-snap")) { this.snap = e.target.checked;
      } else if (e.target.matches(".d3-transform")) {
        state.transform = e.target.value;
        this.updateGizmo();
        this.updateUI();
      } else if (e.target.matches(".d3-space")) {
        state.space = e.target.value;
        if (state.space === "pivot" && state.transform === "scale") state.transform = "move";
        this.updateGizmo();
        this.updateUI();
      } else if (e.target.matches(".d3-filter")) {
        state.filter = e.target.value;
      } else if (e.target.matches("[data-map]") && e.target.files[0])
        this.importMap(e.target.dataset.map, e.target.files[0]).catch(error => { console.error(error); this.status("This image could not be loaded."); }).finally(() => e.target.value = "");
      else if (e.target.type === "number") this.propertyChange(e.target);
    });
    this.canvas.addEventListener("pointerdown", (e) => this.pointerDown(e), true);
    this.canvas.addEventListener("pointermove", (e) => this.pointerMove(e));
    this.canvas.addEventListener("pointerup", (e) => this.pointerUp(e));
    this.canvas.addEventListener("pointercancel", (e) => this.cancelPointer(e));
    this.onKey = (event) => {
      if (!this.panel.classList.contains("d3-model-active")) return;
      const editingText = event.target?.closest?.(
        "input,textarea,select,[contenteditable='true']",
      );
      if (event.key === "Escape") { this.closePopovers(true); if (!editingText) this.select(null); return; }
      if (editingText) return;
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "z") {
        event.preventDefault();
        if (event.shiftKey) this.redo();
        else this.undo();
        return;
      }
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "y") {
        event.preventDefault();
        this.redo();
        return;
      }
      if (event.key === "Delete" || event.key === "Backspace") {
        event.preventDefault();
        this.deleteSelected();
      }

    };
    window.addEventListener("keydown", this.onKey);
    this.onOutsidePointer = event => { if (!this.root.contains(event.target)) this.closePopovers(); };
    document.addEventListener("pointerdown", this.onOutsidePointer);
  }
  closePopovers(focus = false) {
    $$(".d3-popup", this.root).forEach(item => item.hidden = true);
    $$('[data-pop]', this.root).forEach(button => button.setAttribute("aria-expanded", "false"));
    if (focus) this.popAnchor?.focus();
  }
  togglePopover(button) {
    const item = $(".d3-" + button.dataset.pop, this.root);
    const open = item.hidden;
    this.closePopovers();
    if (!open) return;
    this.popAnchor = button;
    item.hidden = false;
    button.setAttribute("aria-expanded", "true");
    const parent = item.offsetParent.getBoundingClientRect();
    const anchor = button.getBoundingClientRect();
    item.style.left = `${Math.max(4, Math.min(anchor.left - parent.left, parent.width - item.offsetWidth - 4))}px`;
    item.style.right = "auto";
    if (button.dataset.pop !== "view-settings") item.style.top = `${anchor.bottom - parent.top + 8}px`;
  }
  propertyTarget() {
    const selected = this.selectedData();
    if (selected.length === 1) return selected[0];
    if (selected.length || ["select", "gizmo"].includes(state.tool)) return null;
    return this.shapeDefaults[state.tool] ||= norm({type:state.tool});
  }
  status(message) {
    const el = $(".d3-status", this.root); el.textContent = message; el.hidden = !message;
    clearTimeout(this.statusTimer); this.statusTimer = setTimeout(() => el.hidden = true, 7000);
  }
  recordHistory(immediate = false) {
    clearTimeout(this.historyTimer);
    if (!immediate) {
      this.historyPending = true;
      this.updateHistoryButtons();
      this.historyTimer = setTimeout(() => this.recordHistory(true), 300);
      return;
    }
    this.historyTimer = 0;
    this.historyPending = false;
    const snapshot = JSON.stringify(actorsByName());
    if (this.history[this.historyIndex] !== snapshot) {
      this.history = this.history.slice(0, this.historyIndex + 1);
      this.history.push(snapshot);
      if (this.history.length > 40) this.history.shift();
      this.historyIndex = this.history.length - 1;
    }
    this.updateHistoryButtons();
  }
  updateHistoryButtons() {
    const undo = $('[data-action="undo"]', this.root);
    const redo = $('[data-action="redo"]', this.root);
    if (undo) undo.disabled = this.historyIndex <= 0 && !this.historyPending;
    if (redo) redo.disabled = this.historyIndex >= this.history.length - 1;
  }
  applyHistory(index) {
    clearTimeout(this.historyTimer);
    this.historyPending = false;
    const snapshot = this.history[index];
    if (!snapshot) return;
    try {
      state.actors = normalizeActors(JSON.parse(snapshot));
    } catch (error) {
      console.error("Unable to restore the model editor history", error);
      return;
    }
    this.historyIndex = index;
    state.selected = [];
    clearThumbnails();
    flushSave();
    scheduleProjectChanged();
    stage?.markDirty();
    this.refresh();
    this.updateHistoryButtons();
  }
  undo() {
    this.recordHistory(true);
    if (this.historyIndex > 0) this.applyHistory(this.historyIndex - 1);
  }
  redo() {
    this.recordHistory(true);
    if (this.historyIndex < this.history.length - 1)
      this.applyHistory(this.historyIndex + 1);
  }
  resize() {
    const rect = this.canvas.getBoundingClientRect();
    if (rect.width < 1 || rect.height < 1) return;
    const width = Math.round(rect.width);
    const height = Math.round(rect.height);
    const pixelRatio = Math.min(window.devicePixelRatio || 1, 1.5);
    if (
      width === this.width &&
      height === this.height &&
      pixelRatio === this.pixelRatio
    )
      return;
    this.width = width;
    this.height = height;
    if (this.pixelRatio !== pixelRatio) this.renderer.setPixelRatio(pixelRatio);
    this.pixelRatio = pixelRatio;
    this.renderer.setSize(width, height, false);
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.invalidate();
  }
  focusModel() {
    const bounds = new THREE.Box3().setFromObject(this.content);
    if (bounds.isEmpty()) return;
    const center = bounds.getCenter(new THREE.Vector3()),
      size = bounds.getSize(new THREE.Vector3());
    const distance = Math.max(3, size.length() * 1.3);
    this.controls.target.copy(center);
    this.camera.position
      .copy(center)
      .add(
        new THREE.Vector3(0.6, 0.5, 0.8).normalize().multiplyScalar(distance),
      );
    this.controls.update();
    requestRender();
  }
  refresh() {
    const currentActor = actor();
    const model = currentActor?.models[currentActor.active];
    if (!model) return;
    this.wireframeOverlay.clear();
    for (const child of this.content.children) disposeGroup(child);
    this.content.clear();
    this.nodes.clear();
    for (const d of model.objects) {
      const node = buildObject(d);
      this.nodes.set(d.id, node);
    }
    for (const d of model.objects) {
      (this.nodes.get(d.parent) || this.content).add(this.nodes.get(d.id));
    }
    state.selected = state.selected.filter((id) => this.nodes.has(id));
    this.updateGizmo();
    if (state.view !== "rendered") this.applyView();
    else {
      this.applyWireframe();
      this.updateUI();
    }
    requestRender();
    stage?.markDirty(currentActor.name);
    updateThumbnails();
  }
  invalidate() {
    requestRender();
  }
  render() {
    this.controls.update();
    for (const helper of this.selectionHelpers.values()) helper.update();
    this.renderer.render(this.scene, this.camera);
  }
  updateUI() {
    const currentActor = actor();
    const model = activeModel();
    if (!currentActor || !model) return;
    const selecting = state.tool === "select";
    $(".d3-name-group", this.root).hidden = !selecting;
    $(".d3-topbar", this.root).classList.toggle("d3-compact-tools", !selecting);
    $(".d3-model-name", this.root).value = model.name;
    const listKey = `${currentActor.active}:${actorRevisions.get(currentActor.name) || 0}:${thumbnailEpoch}`;
    if (this.modelListActor !== currentActor || this.modelListKey !== listKey) {
      this.modelListActor = currentActor;
      this.modelListKey = listKey;
      $(".d3-model-list", this.root).innerHTML = currentActor.models
        .map((item, index) => {
          const src = modelThumbnail(item, currentActor.name);
          return `<button role="listitem" data-model="${index}" class="${currentActor.active === index ? "active" : ""}" title="${escapeHTML(item.name)}"><span class="d3-asset-thumb"><span class="d3-asset-index">${index + 1}</span><img src="${src}" alt=""></span><span class="d3-asset-meta"><span class="d3-asset-name">${escapeHTML(item.name)}</span><span class="d3-asset-size">${item.objects.length} ${item.objects.length === 1 ? "mesh" : "meshes"}</span></span></button>`;
        })
        .join("");
    }

    const selected = this.selectedData();
    const one = this.propertyTarget();
    const actual = selected.length === 1 ? selected[0] : null;
    $(".d3-object-name", this.root).value = actual?.name || "";
    $(".d3-object-name", this.root).disabled = !actual;
    $(".d3-color-swatch", this.root).style.backgroundColor =
      one?.color || "#ffffff";
    $("[data-action='paste']", this.root).disabled = !this.clipboard?.length;
    $(".d3-selection-count", this.root).textContent = one
      ? one.type === "import"
        ? "Imported model"
        : capitalize(one.type)
      : selected.length
        ? `${selected.length} objects selected`
        : "No selection";

    for (const [className, value] of [
      ["color", one?.color || "#ffffff"],
      ["metallic", one?.metallic ?? 0],
      ["smoothness", one?.smoothness ?? 0.5],
      ["opacity", one?.opacity ?? 1],
      ["subdiv", one?.subdivisions || 1],
      ["points", one?.points || 5],
      ["inner", one?.innerAngle ?? 120],
    ]) {
      const input = $(".d3-" + className, this.root);
      if (input) input.value = value;
    }
    $(".d3-color-hex", this.root).value = one?.color || "#ffffff";
    for (const input of $$(".d3-color", this.root)) input.value = one?.color || "#ffffff";
    $(".d3-linear", this.root).checked = !!one?.linear;
    for (const input of $$(".d3-color-panel input, .d3-maps input", this.root)) input.disabled = !one;
    for (const selector of [
      "[data-requires-one]",
      "[data-requires-selection]",
    ]) {
      for (const control of $$(selector, this.root)) {
        const disabled =
          selector === "[data-requires-one]" ? !one : selected.length === 0;
        const controls = control.matches("input,button,select")
          ? [control]
          : $$("input,button,select", control);
        for (const item of controls) item.disabled = disabled;
      }
    }
    for (const field of $$(".d3-transform-field", this.root)) {
      const property = field.dataset.transform;
      const axis = Number(field.dataset.axis);
      const node = this.nodes.get(actual?.id);
      const raw = this.inspectorValues(node, property)?.[axis];
      const value = property === "rotation" ? (raw * 180) / Math.PI : raw;
      field.value = Number.isFinite(value)
        ? String(Number(value.toFixed(3)))
        : "";
      field.disabled = !actual || (state.space === "pivot" && property === "scale");
    }
    for (const item of $$(".d3-star-only", this.root)) {
      item.hidden = one?.type !== "star";
    }

    $(".d3-transform", this.root).value = state.transform;
    $(".d3-transform option[value='scale']", this.root).disabled = state.space === "pivot";
    $(".d3-transform-tools", this.root).hidden = state.tool !== "gizmo";
    $(".d3-shape-options", this.root).hidden = ["select", "gizmo"].includes(state.tool);
    $("[data-pop='mesh-menu']", this.root).innerHTML = `${capitalize(this.lastShape)}<span class="d3-caret"></span>`;
    for (const field of $$(".d3-toolbar-second > .d3-field-block", this.root)) field.hidden = !one;
    $(".d3-geometry-options", this.root).hidden = !one || one.type === "import";
    $(".d3-view-mode", this.root).value = state.view;
    $(".d3-exposure-row", this.root).hidden = state.view !== "rendered";
    $("[data-action='shadows']", this.root).hidden = state.view !== "rendered";
    for (const output of $$('[data-output]', this.root)) output.value = `${Math.round((one?.[output.dataset.output] ?? 0) * 100)}%`;
    for (const img of $$('[data-preview]', this.root)) {
      const key = img.dataset.preview, url = one?.maps?.[key];
      img.hidden = !url; if (url) img.src = url; else img.removeAttribute('src');
      $(`[data-placeholder="${key}"]`, this.root).hidden = !!url;
      $(`[data-map-name="${key}"]`, this.root).textContent = url ? 'Replace texture' : 'Upload texture';
      $(`[data-remove-map="${key}"]`, this.root).disabled = !url;
    }
    $(".d3-material-swatch", this.root).style.backgroundImage = one?.maps?.texture ? `url("${one.maps.texture}")` : "none";
    $(".d3-space", this.root).value = state.space;
    $(".d3-filter", this.root).value = state.filter;
    $(".d3-exposure", this.root).value = state.exposure;
    $("[data-action='grid']", this.root).classList.toggle("active", state.grid);
    $("[data-action='wireframe']", this.root).classList.toggle("active", this.wireframe);
    $("[data-action='shadows']", this.root).classList.toggle("active", this.shadows);
    $(".d3-hierarchy-toggle", this.root).classList.toggle("active", state.showHierarchy);
    const gridHelper = this.scene.children.find(
      (object) => object.isGridHelper,
    );
    if (gridHelper) gridHelper.visible = state.grid;
    const chainButton = $(".d3-chain", this.root);
    chainButton.hidden = false;
    chainButton.disabled = selected.length < 2;
    for (const button of $$('[data-action="parent"]', this.root)) {
      button.disabled = selected.length < 2;
    }
    $(".d3-selection-extra", this.root).hidden = state.tool !== "select";
    $(".d3-box-toggle", this.root).classList.toggle("active", state.boxSelect);
    $(".d3-box-toggle", this.root).setAttribute("aria-pressed", String(state.boxSelect));
    for (const button of $$("[data-tool]", this.root)) {
      button.classList.toggle("active", button.dataset.tool === state.tool);
    }
    $(".d3-add-mesh", this.root).classList.toggle("active", !["select", "gizmo"].includes(state.tool));
    for (const action of ["grid", "wireframe", "shadows"]) {
      $("[data-action='" + action + "']", this.root).setAttribute("aria-pressed", String(action === "grid" ? state.grid : action === "wireframe" ? this.wireframe : this.shadows));
    }
    $(".d3-hierarchy-toggle", this.root).setAttribute("aria-pressed", String(state.showHierarchy));
    $(".d3-hierarchy", this.root).hidden = !state.showHierarchy;
    this.renderHierarchy();
    this.updateSelectionHelpers();
    this.updateHistoryButtons();
    this.canvas.style.cursor = ["select", "gizmo"].includes(state.tool)
      ? "default"
      : "crosshair";
    this.invalidate();
  }
  updateSelectionHelpers() {
    for (const helper of this.selectionHelpers.values()) { this.scene.remove(helper); helper.geometry.dispose(); helper.material.dispose(); }
    this.selectionHelpers.clear();
    for (const id of state.selected) {
      const node = this.nodes.get(id); if (!node) continue;
      const helper = new THREE.BoxHelper(node, id === state.selected.at(-1) ? 0xff7777 : 0xffbcbc);
      helper.material.depthTest = false; helper.renderOrder = 10;
      this.scene.add(helper); this.selectionHelpers.set(id,helper);
    }
  }
  renderHierarchy() {
    const model = activeModel();
    if (!model) return;
    const byParent = new Map();
    for (const d of model.objects) {
      const key = d.parent || "root";
      if (!byParent.has(key)) byParent.set(key, []);
      byParent.get(key).push(d);
    }
    const walk = (p, depth = 0) =>
      depth > 30
        ? ""
        : (byParent.get(p) || [])
            .map(
              (d) =>
                `<button data-object="${escapeHTML(d.id)}" class="${state.selected.includes(d.id) ? "selected" : ""}" style="padding-left:${8 + depth * 13}px"><span>${escapeHTML(d.name)}</span></button>${walk(d.id, depth + 1)}`,
            )
            .join("");
    $(".d3-hierarchy-items", this.root).innerHTML =
      walk("root") || '<span class="d3-empty-tree">Empty model</span>';
  }
  selectedData() {
    return (
      activeModel()?.objects.filter((d) => state.selected.includes(d.id)) || []
    );
  }
  select(id, add = false) {
    if (!id) state.selected = [];
    else if (add) {
      if (state.selected.includes(id))
        state.selected = state.selected.filter((x) => x !== id);
      else state.selected.push(id);
    } else state.selected = [id];
    this.updateGizmo();
    this.updateUI();
    requestRender();
  }
  selectedRoots() {
    return state.selected.map(id => this.nodes.get(id)).filter(node => {
      if (!node) return false;
      for (let p = node.parent; p; p = p.parent) if (state.selected.includes(p.userData.objectId)) return false;
      return true;
    });
  }
  inspectorValues(node, property) {
    if (!node) return null;
    if (state.space !== "world") return property === "rotation" ? [node.rotation.x,node.rotation.y,node.rotation.z] : node[property].toArray();
    node.updateWorldMatrix(true, false);
    const p = new THREE.Vector3(), q = new THREE.Quaternion(), scale = new THREE.Vector3();
    node.matrixWorld.decompose(p,q,scale);
    if (property === "rotation") { const e = new THREE.Euler().setFromQuaternion(q); return [e.x,e.y,e.z]; }
    return (property === "position" ? p : scale).toArray();
  }
  updateGizmo() {
    this.invalidate();
    for (const control of this.gizmos) { control.detach(); control.enabled = false; }
    const node = this.nodes.get(state.selected.at(-1));
    if (!node || state.tool !== "gizmo") return;
    this.content.updateMatrixWorld(true);
    this.transformProxy.scale.set(1,1,1);
    if (state.space === "world") {
      const bounds = new THREE.Box3();
      for (const root of this.selectedRoots()) bounds.expandByObject(root);
      if (bounds.isEmpty()) node.getWorldPosition(this.transformProxy.position);
      else bounds.getCenter(this.transformProxy.position);
      this.transformProxy.quaternion.identity();
    } else {
      node.getWorldPosition(this.transformProxy.position);
      node.getWorldQuaternion(this.transformProxy.quaternion);
    }
    this.transformProxy.updateMatrixWorld(true);
    for (const control of this.gizmos) {
      const wanted = state.transform === "all" || control.mode === ({move:"translate",rotate:"rotate",scale:"scale"}[state.transform]);
      if (!wanted || (state.space === "pivot" && control.mode === "scale")) continue;
      control.enabled = true;
      control.setSpace(state.space === "world" ? "world" : "local");
      control.attach(this.transformProxy);
    }
  }
  captureTransform() {
    this.content.updateMatrixWorld(true);
    this.transformProxy.updateMatrixWorld(true);
    this.transformStart = this.transformProxy.matrixWorld.clone().invert();
    this.transformNodes = this.selectedRoots().map(node => ({ node, world: node.matrixWorld.clone(), children: node.children.map(child => ({child, world:child.matrixWorld.clone()})) }));
  }
  applyTransform() {
    if (!this.transformStart || !this.transformNodes) return;
    this.transformProxy.updateMatrixWorld(true);
    const delta = this.transformProxy.matrixWorld.clone().multiply(this.transformStart);
    for (const {node, world, children} of this.transformNodes) {
      node.parent.updateWorldMatrix(true, false);
      const local = node.parent.matrixWorld.clone().invert().multiply(delta).multiply(world);
      local.decompose(node.position, node.quaternion, node.scale);
      node.updateMatrixWorld(true);
      if (state.space === "pivot") {
        const inv = node.matrixWorld.clone().invert();
        for (const {child, world:original} of children) inv.clone().multiply(original).decompose(child.position, child.quaternion, child.scale);
      }
    }
    this.persistObjects(false);
  }
  persistObjects(full = true) {
    const model = activeModel();
    if (!model) return;
    for (const d of model.objects) {
      const node = this.nodes.get(d.id);
      if (!node) continue;
      d.parent = node.parent?.userData.objectId || null;
      d.position = node.position.toArray();
      d.rotation = [node.rotation.x, node.rotation.y, node.rotation.z];
      d.scale = node.scale.toArray();
      const mesh = node.children.find((c) => c.isMesh || c.userData.d3ModelContent);
      if (mesh) {
        d.meshPosition = mesh.position.toArray();
        d.meshRotation = [mesh.rotation.x, mesh.rotation.y, mesh.rotation.z];
        d.meshScale = mesh.scale.toArray();
      }
    }
    const saveOptions = {
      actorName: actor()?.name,
      recordHistory: !this.gizmoDragging,
    };
    if (full) {
      save(saveOptions);
      stage?.sync();
      updateThumbnails();
      this.renderHierarchy();
    } else save(saveOptions);
  }
  screenPoint(e) {
    const r = this.canvas.getBoundingClientRect();
    this.pointer.set(
      ((e.clientX - r.left) / r.width) * 2 - 1,
      (-(e.clientY - r.top) / r.height) * 2 + 1,
    );
    this.ray.setFromCamera(this.pointer, this.camera);
    return r;
  }
  floorPoint(e) {
    this.screenPoint(e);
    const p = new THREE.Vector3();
    return this.ray.ray.intersectPlane(this.floor, p) ? p : null;
  }
  hit(e) {
    this.screenPoint(e);
    const meshes = [];
    this.content.traverse((o) => {
      if (o.isMesh) meshes.push(o);
    });
    const objectsById = new Map(
      (activeModel()?.objects || []).map((object) => [object.id, object]),
    );
    for (const hit of this.ray.intersectObjects(meshes, false)) {
      const id = this.parentId(hit.object);
      const data = objectsById.get(id);
      if (data && (state.filter === "all" || state.filter === data.type)) return id;
    }
    return null;
  }
  cancelPointer(e) {
    this.touchPointers.delete(e.pointerId);
    if (this.drag?.kind === "draw") {
      const model = activeModel();
      model.objects = model.objects.filter(d => d.id !== this.drag.d.id);
      state.selected = [];
      this.refresh();
    }
    this.drag = null; this.clickStart = null;
    $(".d3-box", this.root).hidden = true;
    this.controls.enabled = true;
    this.controls.enableRotate = true;
  }
  pointerDown(e) {
    if (e.pointerType === "touch") {
      this.touchPointers.add(e.pointerId);
      if (this.touchPointers.size > 1) { this.cancelPointer({pointerId: -1}); this.controls.enableRotate = true; return; }
    }
    if (e.button !== 0 || e.isPrimary === false) return;
    this.controls.enableRotate = true;
    this.controls.mouseButtons.LEFT = THREE.MOUSE.ROTATE;
    const navigating = ["select", "gizmo"].includes(state.tool);
    if (navigating) {
      if (state.tool === "gizmo" && this.gizmos.some(g => g.enabled && g.axis)) return;
      if (state.tool === "select" && state.boxSelect) {
        this.drag = {kind:"box", x:e.clientX, y:e.clientY, add:e.shiftKey};
        this.controls.enabled = e.pointerType === "touch";
        this.controls.enableRotate = false;
        this.canvas.setPointerCapture(e.pointerId);
      } else {
        this.clickStart = {x:e.clientX, y:e.clientY, id:this.hit(e), shift:e.shiftKey};
      }
      return;
    }
    const start = this.floorPoint(e);
    if (!start) return;
    if (this.snap) { start.x = Math.round(start.x * 4) / 4; start.z = Math.round(start.z * 4) / 4; }
    const defaults = this.shapeDefaults[state.tool] ||= norm({type:state.tool});
    const d = norm({...JSON.parse(JSON.stringify(defaults)), id:uid(), type:state.tool, name:capitalize(state.tool), position:[start.x, .125, start.z], width:.25, depth:.25, height:.25});
    this.recordHistory(true);
    activeModel().objects.push(d);
    this.drag = {kind:"draw", start, d};
    this.controls.enabled = e.pointerType === "touch";
    this.controls.enableRotate = false;
    this.canvas.setPointerCapture(e.pointerId);
    state.selected = [d.id];
    this.refresh();
    const node = this.nodes.get(d.id), mesh = node.children.find(c=>c.isMesh);
    mesh.geometry.computeBoundingBox();
    d.position[1] = d.type === "plane" ? .002 : -mesh.geometry.boundingBox.min.y;
    node.position.y = d.position[1];
  }
  pointerMove(e) {
    if (this.touchPointers.size > 1 || !this.drag) return;
    if (this.drag.kind === "box") {
      const r = this.canvas.getBoundingClientRect(),
        box = $(".d3-box", this.root);
      box.hidden = false;
      const x = Math.min(e.clientX, this.drag.x) - r.left,
        y = Math.min(e.clientY, this.drag.y) - r.top;
      box.style.cssText = `left:${x}px;top:${y}px;width:${Math.abs(e.clientX - this.drag.x)}px;height:${Math.abs(e.clientY - this.drag.y)}px`;
      return;
    }
    const end = this.floorPoint(e),
      { start, d } = this.drag;
    if (!end) return;
    if (this.snap) { end.x = Math.round(end.x * 4) / 4; end.z = Math.round(end.z * 4) / 4; }
    const w = Math.max(this.snap ? .25 : .05, Math.abs(end.x - start.x)),
      z = Math.max(this.snap ? .25 : .05, Math.abs(end.z - start.z));
    d.width = w;
    d.depth = z;
    d.height = d.type === "plane" ? 0.025 : Math.max(0.25, Math.min(w, z));
    d.position = [(start.x + end.x) / 2, d.height / 2, (start.z + end.z) / 2];
    const node = this.nodes.get(d.id);
    if (node) {
      node.position.fromArray(d.position);
      const mesh = node.children.find((c) => c.isMesh || c.userData.d3ModelContent);
      if (mesh) {
        mesh.geometry.dispose();
        mesh.geometry = geometry(d);
        mesh.geometry.computeBoundingBox();
        d.position[1] = d.type === "plane" ? .002 : -mesh.geometry.boundingBox.min.y;
        node.position.y = d.position[1];
      }
    }
    requestRender();
  }
  pointerUp(e) {
    this.touchPointers.delete(e.pointerId);
    if (this.clickStart) {
      const click = this.clickStart; this.clickStart = null;
      if (!this.gizmoDragging && Math.hypot(e.clientX-click.x,e.clientY-click.y) < 5) this.select(click.id,click.shift);
    }
    if (!this.drag) return;
    if (this.drag.kind === "box") {
      const p = this.drag,
        r = this.canvas.getBoundingClientRect();
      const minX = Math.min(p.x, e.clientX) - r.left,
        maxX = Math.max(p.x, e.clientX) - r.left,
        minY = Math.min(p.y, e.clientY) - r.top,
        maxY = Math.max(p.y, e.clientY) - r.top;
      if (!p.add) state.selected = [];
      for (const d of activeModel().objects) {
        if (state.filter !== "all" && state.filter !== d.type) continue;
        const node = this.nodes.get(d.id);
        node.updateWorldMatrix(true, true);
        const bounds = new THREE.Box3().setFromObject(node);
        if (bounds.isEmpty()) continue;
        const projected = [];
        for (const x of [bounds.min.x,bounds.max.x]) for (const y of [bounds.min.y,bounds.max.y]) for (const z of [bounds.min.z,bounds.max.z]) projected.push(new THREE.Vector3(x,y,z).project(this.camera));
        if (!projected.some(p=>p.z>=-1 && p.z<=1)) continue;
        const xs=projected.map(p=>(p.x+1)*r.width/2), ys=projected.map(p=>(1-p.y)*r.height/2);
        if (Math.max(...xs)>=minX && Math.min(...xs)<=maxX && Math.max(...ys)>=minY && Math.min(...ys)<=maxY && !state.selected.includes(d.id)) state.selected.push(d.id);
      }
      $(".d3-box", this.root).hidden = true;
      this.updateGizmo();
      this.updateUI();
    } else {
      this.persistObjects();
      this.refresh();
    }
    this.drag = null;
    this.controls.enabled = true;
    this.controls.enableRotate = true;
    try {
      this.canvas.releasePointerCapture(e.pointerId);
    } catch {}
  }
  async action(which) {
    if (which === "add-menu") {
      const menu = $(".d3-add-menu", this.root);
      menu.hidden = !menu.hidden;
    } else if (which === "mesh-menu") {
      const one = this.selectedData()[0];
      if (one && ["cube","sphere","cone","cylinder","plane","torus","star"].includes(one.type)) this.lastShape = one.type;
      else state.selected = [];
      state.tool = this.lastShape; this.closePopovers(); this.updateGizmo(); this.updateUI();
    } else if (which === "close-pop") {
      this.closePopovers(true);
    } else if (which === "subdiv-up" || which === "subdiv-down") {
      const input = $(".d3-subdiv", this.root);
      input.value = clamp((Number(input.value) || 1) * (which === "subdiv-up" ? 2 : .5), 1, 16);
      this.propertyChange(input);
    } else if (which === "copy") {
      this.clipboard = this.selectedData().map((object) => JSON.parse(JSON.stringify(object)));
      this.updateUI();
    } else if (which === "paste") {
      const model = activeModel();
      if (!model || !this.clipboard?.length) return;
      const ids = new Map(this.clipboard.map((object) => [object.id, uid()]));
      const copies = this.clipboard.map((object) => {
        const copy = norm(JSON.parse(JSON.stringify(object)));
        copy.id = ids.get(object.id);
        copy.name = `${object.name} copy`;
        copy.parent = ids.get(object.parent) || null;
        copy.position = [object.position[0] + .25, object.position[1], object.position[2] + .25];
        return copy;
      });
      model.objects.push(...copies);
      state.selected = copies.map((object) => object.id);
      save({ sceneChanged: true, actorName: actor()?.name });
      this.refresh();
    } else if (which === "grid") {
      state.grid = !state.grid;
      const helper = this.scene.children.find((object) => object.isGridHelper);
      if (helper) helper.visible = state.grid;
      this.updateUI();
      requestRender();
    } else if (which === "wireframe") {
      this.wireframe = !this.wireframe;
      this.applyView();
    } else if (which === "shadows") {
      this.shadows = !this.shadows;
      this.renderer.shadowMap.enabled = this.shadows;
      this.scene.traverse((object) => {
        if (object.isMesh) for (const material of Array.isArray(object.material) ? object.material : [object.material]) {
          if (material) material.needsUpdate = true;
        }
      });
      this.updateUI();
      requestRender();
    } else if (which === "zoom-in" || which === "zoom-out") {
      const scale = which === "zoom-in" ? .8 : 1.25;
      this.camera.position.sub(this.controls.target).multiplyScalar(scale).add(this.controls.target);
      this.controls.update();
      requestRender();
    } else if (which === "zoom-reset") {
      this.focusModel();
    } else if (which === "export") {
      const exportRoot = new THREE.Group();
      try {
        const objects = activeModel().objects;
        await Promise.all(objects.filter(d=>d.type === "import").map(d=>loadImportedTemplate(d)));
        const nodes = new Map(objects.map(d=>[d.id, buildObject(d)]));
        for (const d of objects) (nodes.get(d.parent) || exportRoot).add(nodes.get(d.id));
        const result = await new GLTFExporter().parseAsync(exportRoot, { binary: true, onlyVisible: false });
        const url = URL.createObjectURL(new Blob([result], { type: "model/gltf-binary" }));
        const link = document.createElement("a");
        link.href = url;
        link.download = `${(activeModel()?.name || "model").replace(/[^a-z0-9_-]+/gi, "_")}.glb`;
        document.body.append(link);
        link.click();
        link.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
      } catch (error) {
        console.error("Unable to export model", error);
        this.status("Could not export this model. Try again after its assets finish loading.");
      } finally { disposeGroup(exportRoot); }
    } else if (which === "empty") {
      $(".d3-add-menu", this.root).hidden = true;
      const currentActor = actor();
      currentActor.models.push({
        id: uid(),
        name: `model${currentActor.models.length + 1}`,
        objects: [],
      });
      currentActor.active = currentActor.models.length - 1;
      state.selected = [];
      save({ sceneChanged: true, actorName: currentActor.name });
      this.refresh();
    } else if (which === "import") {
      $(".d3-add-menu", this.root).hidden = true;
      $(".d3-import", this.root).click();
    } else if (which === "box") {
      state.boxSelect = !state.boxSelect;
      this.updateUI();
    } else if (which === "undo") {
      this.undo();
    } else if (which === "redo") {
      this.redo();
    } else if (which === "duplicate") {
      this.duplicateSelected();
    } else if (which === "delete") {
      this.deleteSelected();
    } else if (which === "parent" || which === "chain") {
      this.parent(which === "chain");
    }
  }
  duplicateSelected() {
    const model = activeModel();
    if (!model || !state.selected.length) return;
    const selected = new Set(state.selected);
    const originals = model.objects.filter((object) => selected.has(object.id));
    const idMap = new Map(originals.map((object) => [object.id, uid()]));
    const copies = originals.map((object) => {
      const copy = norm(JSON.parse(JSON.stringify(object)));
      copy.id = idMap.get(object.id);
      copy.name = `${object.name} copy`;
      copy.parent = selected.has(object.parent)
        ? idMap.get(object.parent)
        : object.parent;
      copy.position = [
        object.position[0] + 0.25,
        object.position[1],
        object.position[2] + 0.25,
      ];
      return copy;
    });
    model.objects.push(...copies);
    state.selected = copies.map((object) => object.id);
    save({ sceneChanged: true, actorName: actor()?.name });
    this.refresh();
  }
  parent(chain) {
    if (state.selected.length < 2) return;
    const ids = state.selected.slice();
    for (const id of ids) this.content.attach(this.nodes.get(id));
    if (chain) {
      let parent = this.nodes.get(ids.at(-1));
      for (let i = ids.length - 2; i >= 0; i--) {
        const child = this.nodes.get(ids[i]);
        parent.attach(child);
        parent = child;
      }
    } else {
      const parent = this.nodes.get(ids.at(-1));
      for (const id of ids.slice(0, -1)) parent.attach(this.nodes.get(id));
    }
    this.persistObjects();
    this.refresh();
  }
  deleteSelected() {
    const model = activeModel();
    if (!model || !state.selected.length) return;
    for (const id of state.selected) {
      const node = this.nodes.get(id);
      if (node)
        for (const child of [...node.children])
          if (child.userData.objectId) this.content.attach(child);
    }
    this.persistObjects(false);
    model.objects = model.objects.filter((d) => !state.selected.includes(d.id));
    state.selected = [];
    save({ sceneChanged: true, actorName: actor()?.name });
    this.refresh();
  }
  propertyChange(el) {
    if (el.classList.contains("d3-model-name")) {
      const currentActor = actor();
      const model = activeModel();
      if (model) {
        model.name = el.value;
        save({ actorName: currentActor?.name });
        const row = $(
          `.d3-model-list [data-model="${currentActor?.active}"]`,
          this.root,
        );
        if (row) {
          row.title = model.name;
          $(".d3-asset-name", row).textContent = model.name;
        }
      }
      return;
    }
    if (el.classList.contains("d3-background")) { this.scene.background = new THREE.Color(el.value); requestRender(); return; }
    if (el.classList.contains("d3-exposure")) {
      state.exposure = Number(el.value);
      this.renderer.toneMappingExposure = state.exposure;

      requestRender();
      return;
    }
    if (el.classList.contains("d3-grid")) {
      state.grid = el.checked;
      const helper = this.scene.children.find((o) => o.isGridHelper);
      if (helper) helper.visible = state.grid;
      requestRender();
      return;
    }
    if (el.matches(".d3-transform-field")) {
      const selected = this.selectedData();
      if (selected.length !== 1) return;
      const one = selected[0];
      const value = Number(el.value);
      if (!Number.isFinite(value)) return;
      const property = el.dataset.transform;
      const axis = Number(el.dataset.axis);
      if (state.space === "pivot" && property === "scale") return;
      const node = this.nodes.get(one.id);
      node.updateWorldMatrix(true, true);
      const children = node.children.map(child => ({child, world: child.matrixWorld.clone()}));
      const p = new THREE.Vector3(), q = new THREE.Quaternion(), sc = new THREE.Vector3();
      (state.space === "world" ? node.matrixWorld : node.matrix).decompose(p,q,sc);
      const rotation = new THREE.Euler().setFromQuaternion(q);
      const vector = property === "position" ? p : property === "scale" ? sc : rotation;
      vector[["x","y","z"][axis]] = property === "rotation" ? THREE.MathUtils.degToRad(value) : value;
      if (property === "rotation") q.setFromEuler(rotation);
      if (Math.abs(sc.x * sc.y * sc.z) < 1e-8) return;
      const matrix = new THREE.Matrix4().compose(p,q,sc);
      if (state.space === "world") matrix.premultiply(node.parent.matrixWorld.clone().invert());
      matrix.decompose(node.position,node.quaternion,node.scale);
      node.updateMatrixWorld(true);
      if (state.space === "pivot") for (const {child,world} of children) node.matrixWorld.clone().invert().multiply(world).decompose(child.position,child.quaternion,child.scale);
      this.persistObjects();
      this.updateGizmo();
      requestRender();
      return;
    }
    const one = this.propertyTarget();
    if (!one) return;
    const map = {
      "d3-object-name": "name",
      "d3-color": "color",
      "d3-color-hex": "color",
      "d3-metallic": "metallic",
      "d3-smoothness": "smoothness",
      "d3-opacity": "opacity",
      "d3-subdiv": "subdivisions",
      "d3-linear": "linear",
      "d3-points": "points",
      "d3-inner": "innerAngle",
    };
    let key;
    for (const [cls, k] of Object.entries(map))
      if (el.classList.contains(cls)) key = k;
    if (!key) return;
    if (
      key === "color" &&
      el.classList.contains("d3-color-hex") &&
      !/^#[0-9a-f]{6}$/i.test(el.value)
    )
      return;
    one[key] =
      el.type === "checkbox"
        ? el.checked
        : el.type === "number" || el.type === "range"
          ? Number(el.value)
          : el.value;
    if (key === "subdivisions") one[key] = 2 ** Math.ceil(Math.log2(clamp(one[key] || 1, 1, 16)));
    if (key === "points") one[key] = clamp(Math.round(one[key]), 3, 24);
    if (key === "innerAngle") one[key] = clamp(one[key], 30, 175);
    if (["metallic", "smoothness", "opacity"].includes(key)) { one[key] = clamp(one[key], 0, 1); $("[data-output=" + key + "]", this.root).value = `${Math.round(one[key] * 100)}%`; }
    if (!["select", "gizmo"].includes(state.tool)) this.shapeDefaults[state.tool] = norm({...JSON.parse(JSON.stringify(one)), id:uid(), parent:null, position:[0,0,0], rotation:[0,0,0], scale:[1,1,1], meshPosition:[0,0,0], meshRotation:[0,0,0], meshScale:[1,1,1]});
    if (!this.nodes.has(one.id)) { this.updateUI(); return; }
    if (
      one.type === "import" &&
      ["color", "metallic", "smoothness", "opacity"].includes(key)
    ) {
      one.materialOverride = true;
    }
    save({ actorName: actor()?.name });
    if (key === "color") {
      $(".d3-color-swatch", this.root).style.backgroundColor = one.color;
      $(".d3-color-hex", this.root).value = one.color;
      for (const input of $$(".d3-color", this.root)) input.value = one.color;
    }
    if (key === "name") this.nodes.get(one.id).name = one.name;
    else if (
      key === "color" ||
      key === "metallic" ||
      key === "smoothness" ||
      key === "opacity"
    ) {
      this.nodes.get(one.id).traverse((object) => {
        if (!object.isMesh || object.userData.d3WireframeOverlay || !object.material || this.parentId(object) !== one.id) return;
        const materials = Array.isArray(object.material)
          ? object.material
          : [object.material];
        for (const item of materials) {
          item.color?.set(one.color);
          if ("metalness" in item) item.metalness = one.metallic;
          if ("roughness" in item) item.roughness = 1 - one.smoothness;
          item.opacity = one.opacity;
          item.transparent = one.opacity < 1 || !!one.maps.opacity;
          item.depthWrite = one.opacity >= 1;
          item.needsUpdate = true;
        }
      });
    } else if (key !== "name") this.refresh();
    this.renderHierarchy();
    stage?.sync();
    updateThumbnails();
    requestRender();
  }
  applyView() {
    this.wireframeOverlay.clear();
    const model = activeModel();
    if (!model) return;
    const objectsById = new Map(model.objects.map(object => [object.id, object]));
    this.content.traverse((object) => {
      if (!object.isMesh) return;
      const data = objectsById.get(this.parentId(object));
      if (!data) return;
      const sourceMaterial = object.userData.d3SourceMaterial;
      const sourceMaterials = Array.isArray(sourceMaterial)
        ? sourceMaterial
        : sourceMaterial
          ? [sourceMaterial]
          : [];
      const preserveImported =
        data.type === "import" && sourceMaterials.length > 0;
      const currentMaterials = Array.isArray(object.material)
        ? object.material
        : [object.material];

      if (state.view === "rendered" && preserveImported) {
        for (const item of currentMaterials) {
          if (item && !sourceMaterials.includes(item)) item.dispose();
        }
        object.material = sourceMaterial;
        if (data.materialOverride) setMaterialProperties(object, data);
        applyMaps(object, data);
        return;
      }

      for (const item of currentMaterials) {
        if (item && !sourceMaterials.includes(item)) item.dispose();
      }
      if (state.view === "unlit") {
        const basicMaterial = (source) =>
          new THREE.MeshBasicMaterial({
            color: preserveImported && !data.materialOverride ? source?.color || data.color : data.color,
            map: preserveImported ? source?.map || null : null,
            transparent: data.opacity < 1,
            opacity: data.opacity,
            depthWrite: data.opacity >= 1,
            side: THREE.DoubleSide,
          });
        object.material =
          preserveImported && Array.isArray(sourceMaterial)
            ? sourceMaterials.map(basicMaterial)
            : basicMaterial(sourceMaterials[0]);
        applyMaps(object, data);
      } else if (state.view === "madcap") {
        const matcapMaterial = (source) =>
          new THREE.MeshMatcapMaterial({
            matcap: matcapTexture,
            color: this.wireframe ? (preserveImported && !data.materialOverride ? source?.color || data.color : data.color) : 0xffffff,
            map: this.wireframe && preserveImported ? source?.map || null : null,
            transparent: data.opacity < 1,
            opacity: data.opacity,
            depthWrite: data.opacity >= 1,
            side: THREE.DoubleSide,
          });
        object.material =
          preserveImported && Array.isArray(sourceMaterial)
            ? sourceMaterials.map(matcapMaterial)
            : matcapMaterial(sourceMaterials[0]);
        if (this.wireframe) applyMaps(object, data);
      } else {
        object.material = material(data);
        applyMaps(object, data);
      }
    });
    this.applyWireframe();
    this.updateUI();
    requestRender();
  }
  applyWireframe() {
    this.wireframeOverlay.update(this.content, this.wireframe);
  }
  parentId(o) {
    while (o && !o.userData.objectId) o = o.parent;
    return o?.userData.objectId;
  }
  async importModel(file) {
    const currentActor = actor();
    if (!currentActor) return;
    const generation = renderAssetGeneration;
    const format = file.name.toLowerCase().endsWith(".obj")
      ? "obj"
      : file.name.toLowerCase().endsWith(".glb")
        ? "glb"
        : "gltf";
    const assetId = uid();
    const bytes = new Uint8Array(await file.arrayBuffer());
    if (generation !== renderAssetGeneration) return;
    let source = { format, assetId };
    try {
      await storeAsset(assetId, new Blob([bytes], { type: file.type }));
      assetBytes.set(assetId, bytes);
    } catch {
      source = { format, assetId, data: bytesToBase64(bytes) };
    }
    if (generation !== renderAssetGeneration) {
      assetBytes.delete(assetId);
      try { await deleteAsset(assetId); } catch {}
      return;
    }
    const d = norm({ type: "import", name: file.name, source });
    try {
      await loadImportedTemplate(d);
    } catch (error) {
      assetBytes.delete(assetId);
      try { await deleteAsset(assetId); } catch {}
      throw error;
    }
    if (generation !== renderAssetGeneration || !Object.values(state.actors).includes(currentActor)) return;
    const model = {
      id: uid(),
      name: file.name.replace(/\.[^.]+$/, ""),
      objects: [d],
    };
    currentActor.models.push(model);
    currentActor.active = currentActor.models.length - 1;
    save({ sceneChanged: true, actorName: currentActor.name });
    if (this.root.isConnected && actor() === currentActor) {
      state.selected = [d.id];
      this.refresh();
    }
    updateThumbnails();
  }
  async importMap(kind, file) {
    const one = this.propertyTarget();
    if (!one) return;
    const currentActor = actor();
    const generation = renderAssetGeneration;
    const isModelObject = this.nodes.has(one.id);
    const data = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = () => reject(reader.error);
      reader.onload = () => resolve(reader.result);
      reader.readAsDataURL(file);
    });
    await new Promise((resolve, reject) => { const image = new Image(); image.onload = resolve; image.onerror = () => reject(new Error("Invalid texture image")); image.src = data; });
    if (generation !== renderAssetGeneration) return;
    one.maps[kind] = data;
    if (isModelObject) save({ sceneChanged: true, actorName: currentActor?.name });
    if (this.root.isConnected && actor() === currentActor) {
      if (this.nodes.has(one.id)) this.refresh();
      else this.updateUI();
    }
  }
  dispose() {
    clearTimeout(this.historyTimer);
    this.resizeObserver.disconnect();
    window.removeEventListener("keydown", this.onKey);
    document.removeEventListener("pointerdown", this.onOutsidePointer);
    this.controls.dispose();
    for (const control of this.gizmos) control.dispose();
    for (const helper of this.selectionHelpers.values()) { helper.geometry.dispose(); helper.material.dispose(); }
    clearTimeout(this.statusTimer);
    this.wireframeOverlay.clear();
    for (const child of this.content.children) disposeGroup(child);
    this.renderer.dispose();
    this.renderer.forceContextLoss?.();
    this.root.remove();
    if (editor === this) editor = null;
  }
}
function escapeHTML(s) {
  return String(s).replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
}
const capitalize = (s) => s[0].toUpperCase() + s.slice(1);
function thumbnail(model) {
  if (stage && !stage.disposed && !stage.contextLost) {
    try {
      return stage.renderThumbnail(model);
    } catch (error) {
      console.warn("Unable to render a 3D model thumbnail", error);
    }
  }
  const icon = `<svg xmlns="http://www.w3.org/2000/svg" width="96" height="72" viewBox="0 0 96 72"><rect width="96" height="72" rx="8" fill="#f3f4f8"/><path d="m48 14 23 13v19L48 59 25 46V27zM25 27l23 14 23-14M48 41v18" fill="#855cd6" fill-opacity=".22" stroke="#855cd6" stroke-width="2" stroke-linejoin="round"/></svg>`;
  return `data:image/svg+xml,${encodeURIComponent(icon)}`;
}
const thumbnailCache = new Map();
let thumbnailEpoch = 0;
let thumbnailsScheduled = false;
function clearThumbnails() {
  thumbnailCache.clear();
  thumbnailEpoch++;
}
function modelThumbnail(model, actorName) {
  const version = actorRevisions.get(actorName) || 0;
  const cached = thumbnailCache.get(model.id);
  if (cached?.model === model && cached.version === version) {
    // Keep frequently visible models in a bounded LRU cache.
    thumbnailCache.delete(model.id);
    thumbnailCache.set(model.id, cached);
    return cached.src;
  }
  const src = thumbnail(model);
  thumbnailCache.set(model.id, { model, version, src });
  if (thumbnailCache.size > 128) thumbnailCache.delete(thumbnailCache.keys().next().value);
  return src;
}
function updateThumbnails() {
  if (thumbnailsScheduled) return;
  thumbnailsScheduled = true;
  requestAnimationFrame(() => {
    thumbnailsScheduled = false;
    syncThumbnails();
  });
}
function syncThumbnails() {
  const vm = window.vm;
  if (!vm || projectLoading) return;
  const targetsByName = new Map(vm.runtime.targets
    .filter(target => target.isOriginal && !target.isStage)
    .map(target => [target.sprite.name, target]));
  const tiles = $$('[class*="sprite-selector-item_sprite-selector-item_"]');
  for (const tile of tiles) {
    const name = $('[class*="sprite-selector-item_sprite-name_"]', tile)?.textContent;
    const target = targetsByName.get(name);
    const data = target && dataForTarget(target);
    const model = data?.models?.[data.active];
    if (!model) {
      $(".d3-thumbnail", tile)?.remove();
      continue;
    }
    const src = modelThumbnail(model, data.name);
    let img = $(".d3-thumbnail", tile);
    if (!img) {
      img = document.createElement("img");
      img.className = "d3-thumbnail";
      img.alt = "3D model thumbnail";
      $('[class*="sprite-selector-item_sprite-image-outer_"]', tile)?.append(img);
    }
    if (img.src !== src) img.src = src;
  }
}
function updateActorLabels() {
  const pane = $(
    '[class*="target-pane_target-pane_"],[class*="sprite-selector-item_sprite-selector-item_"]',
  );
  if (!pane) return;
  const relabel = (value) => value
    .replace(/\bSprites\b/g, "Actors")
    .replace(/\bSprite\b/g, "Actor")
    .replace(/\bBackdrops\b/g, "Scenes")
    .replace(/\bBackdrop\b/g, "Scene")
    .replace(/\bbackdrops\b/g, "scenes")
    .replace(/\bbackdrop\b/g, "scene");
  const walker = document.createTreeWalker(pane, NodeFilter.SHOW_TEXT);
  let node;
  while ((node = walker.nextNode())) {
    if (node.parentElement?.closest("input,textarea,[contenteditable]"))
      continue;
    const text = node.nodeValue;
    if (/\b(?:Sprites?|Backdrops?|backdrops?)\b/.test(text))
      node.nodeValue = relabel(text);
  }
  for (const el of $$("[title],[aria-label]", pane)) {
    for (const attr of ["title", "aria-label"]) {
      const v = el.getAttribute(attr);
      if (v && /\b(?:Sprites?|Backdrops?|backdrops?)\b/.test(v))
        el.setAttribute(attr, relabel(v));
    }
  }
  syncTargetPoseControls();
}

let poseControlFrame = 0;
let poseControlVM = null;
let poseControlVMHandler = null;
let poseControlPane = null;
let poseControlObserver = null;

function schedulePoseControlsSync() {
  if (poseControlFrame) return;
  poseControlFrame = requestAnimationFrame(() => {
    poseControlFrame = 0;
    syncTargetPoseControls();
  });
}

function bindPoseControlVM(vm) {
  if (poseControlVM === vm) return;
  if (poseControlVM && poseControlVMHandler) {
    poseControlVM.off?.("TARGETS_UPDATE", poseControlVMHandler);
    poseControlVM.removeListener?.("TARGETS_UPDATE", poseControlVMHandler);
  }
  poseControlVM = vm;
  poseControlVMHandler = () => schedulePoseControlsSync();
  poseControlVM?.on?.("TARGETS_UPDATE", poseControlVMHandler);
}

function watchPoseControlPane(pane) {
  if (poseControlPane === pane) return;
  poseControlObserver?.disconnect();
  poseControlPane = pane;
  poseControlObserver = null;
  if (!pane) return;
  poseControlObserver = new MutationObserver(schedulePoseControlsSync);
  poseControlObserver.observe(pane, { childList: true, subtree: true });
}

function createPoseField(axis, label, step) {
  const wrapper = document.createElement("label");
  wrapper.className = "d3-pose-field";
  const caption = document.createElement("span");
  caption.textContent = label;
  const input = document.createElement("input");
  input.type = "number";
  input.step = String(step);
  input.dataset.d3Pose = axis;
  input.setAttribute(
    "aria-label",
    `${label} ${axis === "z" ? "position" : "rotation"}${axis === "z" ? "" : " in degrees"}`,
  );
  input.addEventListener("change", () => {
    const target = window.vm?.editingTarget;
    const value = Number(input.value);
    if (!target || target.id !== input.dataset.targetId || !Number.isFinite(value)) return;
    if (axis === "z") {
      setRuntimeTransform(target, "height", value / SCRATCH_UNITS_PER_WORLD_UNIT);
    } else if (axis === "yaw") {
      // Keep one visible heading by storing edits in the base direction and
      // clearing the extra yaw offset.
      setDirection3D(target, value);
      setRuntimeTransform(target, "yaw", 0);
    } else {
      setRuntimeTransform(target, axis, value);
    }
    schedulePoseControlsSync();
  });
  input.addEventListener("keydown", (event) => {
    if (event.key === "Enter") input.blur();
  });
  wrapper.append(caption, input);
  return wrapper;
}

function syncTargetPoseControls() {
  const target = window.vm?.editingTarget;
  const pane = $('[class*="target-pane_target-pane_"]');
  watchPoseControlPane(pane);
  if (!pane) return;
  const info = $('[class*="sprite-info_sprite-info_"]', pane);
  if (!info) return;

  const actorData = target && !target.isStage ? dataForTarget(target) : null;
  if (!target || target.isStage || !actorData?.models?.length) {
    pane.querySelector(".d3-target-rotation")?.remove();
    pane.querySelector(".d3-target-z")?.remove();
    for (const item of $$(".d3-native-direction-hidden", info)) {
      item.classList.remove("d3-native-direction-hidden");
    }
    return;
  }

  const yInput = [...$$('input[type="number"]', info)].find(
    (input) => input.placeholder?.toLowerCase() === "y",
  );
  const positionRow = yInput?.closest('[class*="sprite-info_row_"]');
  if (positionRow && !positionRow.querySelector(".d3-target-z")) {
    const zField = createPoseField("z", "Z", 0.1);
    zField.classList.add("d3-target-z");
    zField.title = "Vertical position in stage units";
    positionRow.append(zField);
  }

  const directionPicker = info.querySelector('[class*="direction-picker_button-row_"]');
  const nativeDirection = directionPicker?.closest('[class*="sprite-info_larger-input_"]');
  nativeDirection?.classList.add("d3-native-direction-hidden");

  let rotation = pane.querySelector(".d3-target-rotation");
  if (!rotation) {
    rotation = document.createElement("div");
    rotation.className = "d3-target-rotation";
    rotation.setAttribute("role", "group");
    rotation.setAttribute("aria-label", "3D rotation");
    const heading = document.createElement("span");
    heading.className = "d3-target-rotation-title";
    heading.textContent = "3D rotation";
    const fields = document.createElement("div");
    fields.className = "d3-target-rotation-fields";
    fields.append(
      createPoseField("yaw", "Yaw", 1),
      createPoseField("pitch", "Pitch", 1),
      createPoseField("roll", "Roll", 1),
    );
    rotation.append(heading, fields);
    info.after(rotation);
  }

  const transform = runtimeTransform(target, actorData);
  const values = {
    z: positionZ(target),
    yaw: Number(target.direction ?? 90) - transform.yaw,
    pitch: transform.pitch,
    roll: transform.roll,
  };
  for (const input of $$("[data-d3-pose]", pane)) {
    input.dataset.targetId = target.id;
    if (document.activeElement !== input) {
      input.value = String(Number((values[input.dataset.d3Pose] ?? 0).toFixed(1)));
    }
  }
}

let domScheduled = false;
let storageWaitScheduled = false;
function scheduleSyncDOM() {
  if (domScheduled) return;
  domScheduled = true;
  requestAnimationFrame(syncDOM);
}

function syncDOM() {
  domScheduled = false;
  const vm = window.vm;
  if (!vm || projectLoading) return;
  installVmHooks(vm);
  if (!state.storageKey) {
    if (!storageWaitScheduled) {
      storageWaitScheduled = true;
      readyPromise.finally(() => {
        storageWaitScheduled = false;
        scheduleSyncDOM();
      });
    }
    return;
  }

  const target = vm.editingTarget;
  const stageHost = $('[class*="stage_stage_"]');
  if (!stageHost && stage) {
    stage.dispose();
    stage = null;
  }
  if (
    stageHost &&
    (!stage || stage.host !== stageHost || !stage.canvas.isConnected)
  ) {
    stage?.dispose();
    stage = new Stage3D(stageHost);
  }
  if (stage) {
    stage.bindVM(vm);
    stage.sync();
  }

  const rolePanels = $$('[role="tabpanel"]');
  const roleTabs = $$('[role="tab"]');
  const panels = rolePanels.length
    ? rolePanels
    : $$('[class*="gui_tab-panel_"]');
  const tabs = roleTabs.length ? roleTabs : $$('[class*="gui_tab_"]');
  const costumeTab = tabs.find((item) =>
    /costumes?/i.test(
      `${item.textContent} ${item.getAttribute("aria-label") || ""}`,
    ),
  );
  const modelTab = costumeTab || tabs[1];
  const panelIndex = modelTab ? tabs.indexOf(modelTab) : 1;
  const modelPanel =
    document.getElementById(modelTab?.getAttribute("aria-controls")) ||
    panels[panelIndex] ||
    panels[1];
  const visible =
    !!modelTab &&
    (modelTab.getAttribute("aria-selected") === "true" ||
      modelTab.className.includes("is-selected"));
  document.documentElement.classList.toggle("d3-model-open", visible);
  // Earlier revisions injected a second Find box into the tab strip.
  // Remove it if a live editor still has that node.
  document.querySelector(".d3-find-container")?.remove();

  if (modelPanel && visible && target && !target.isStage) {
    modelPanel.classList.remove("d3-scene-active");
    modelPanel.classList.add("d3-model-active");
    if (!editor || editor.panel !== modelPanel || !editor.root.isConnected) {
      editor?.dispose();
      editor = new ModelEditor(modelPanel);
      editor.updateUI();
    } else if (editor.lastTarget !== target.id) {
      state.selected = [];
      editor.refresh();
      editor.updateUI();
    }
    editor.lastTarget = target.id;
    editor.resize();
  } else {
    modelPanel?.classList.remove("d3-model-active");
    if (editor && !editor.root.isConnected) {
      editor.dispose();
      editor = null;
    }
  }

  if (modelPanel && visible && target?.isStage) {
    modelPanel.classList.add("d3-scene-active");
    if (!sceneEditor || sceneEditor.panel !== modelPanel || !sceneEditor.root.isConnected) {
      sceneEditor?.dispose();
      sceneEditor = new SceneEditor(modelPanel);
    } else sceneEditor.sync();
  } else {
    modelPanel?.classList.remove("d3-scene-active");
    if (sceneEditor && !sceneEditor.root.isConnected) sceneEditor.dispose();
  }

  document.documentElement.classList.toggle(
    "d3-actor-target",
    !!target && !target.isStage,
  );
  document.documentElement.classList.toggle("d3-stage-target", !!target?.isStage);
  if (target && !target.isStage) {
    actor();
    updateThumbnails();
  }
  bindPoseControlVM(vm);
  updateActorLabels();
}

const observer = new MutationObserver((mutations) => {
  const relevant = mutations.some((mutation) => {
    const target =
      mutation.target.nodeType === Node.ELEMENT_NODE
        ? mutation.target
        : mutation.target.parentElement;
    if (target?.closest?.(".d3-editor")) return false;
    return [...mutation.addedNodes, ...mutation.removedNodes].some((node) => {
      if (node.nodeType !== Node.ELEMENT_NODE) return false;
      return (
        node.matches?.(
          '[class*="stage_stage_"],[class*="gui_tab-panel_"],[class*="target-pane_target-pane_"],[class*="sprite-selector-item_sprite-selector-item_"]',
        ) ||
        node.querySelector?.(
          '[class*="stage_stage_"],[class*="gui_tab-panel_"],[class*="target-pane_target-pane_"],[class*="sprite-selector-item_sprite-selector-item_"]',
        )
      );
    });
  });
  if (relevant) scheduleSyncDOM();
});
const appRoot = $("#app");
if (appRoot) observer.observe(appRoot, { childList: true, subtree: true });

document.addEventListener("click", (event) => {
  if (
    event.target?.closest?.(
      '[role="tab"],[class*="sprite-selector-item_sprite-selector-item_"]',
    )
  )
    scheduleSyncDOM();
});
document.addEventListener("keydown", (event) => {
  if (
    event.target?.closest?.(
      '[role="tab"],[class*="sprite-selector-item_sprite-selector-item_"]',
    ) &&
    ["Enter", " "].includes(event.key)
  )
    scheduleSyncDOM();
});

const ready = setInterval(() => {
  const vm = window.vm;
  if (!vm?.runtime?.targets?.length) return;
  clearInterval(ready);
  installVmHooks(vm);
  readyPromise.then(() => {
    if (!projectLoading) projectLoadedOnce = true;
    syncDOM();
  });
}, 100);
