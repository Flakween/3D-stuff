/*
 * Core runtime glue shared by the model editor and the live 3D stage.
 * This module deliberately has no UI or Three.js dependencies so project
 * loading, runtime event ownership, and hierarchy validation stay testable
 * independently of the editor surface.
 */

export const SCRATCH_UNITS_PER_WORLD_UNIT = 60;

const finiteOr = (value, fallback) => {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
};

/**
 * Convert a TurboWarp target pose into the engine's right-handed, Y-up world.
 * Scratch X maps to world X, Scratch Y maps to negative Z, and actor direction
 * remains the familiar Scratch heading with an optional 3D yaw offset.
 * The actor faces local +X, so pitch rotates around local Z and roll around
 * local X. This matches the forward vector used by the motion blocks.
 */
export function scratchTargetPose(target, transform = {}) {
  const x = finiteOr(target?.x, 0);
  const y = finiteOr(target?.y, 0);
  const direction = finiteOr(target?.direction, 90);
  const size = finiteOr(target?.size, 100);
  const height = finiteOr(transform.height, 0);
  const yaw = finiteOr(transform.yaw, 0);
  const pitch = finiteOr(transform.pitch, 0);
  const roll = finiteOr(transform.roll, 0);
  const degreesToRadians = Math.PI / 180;

  return {
    x,
    y,
    direction,
    size,
    visible: target?.visible !== false,
    height,
    yaw,
    pitch,
    roll,
    position: [x / SCRATCH_UNITS_PER_WORLD_UNIT, height, -y / SCRATCH_UNITS_PER_WORLD_UNIT],
    rotation: [
      roll * degreesToRadians,
      (90 - direction + yaw) * degreesToRadians,
      pitch * degreesToRadians,
    ],
    scale: size / 100,
  };
}

/** A sprite faces local +X; Scratch Y maps to world -Z and height to world Y. */
export function forwardStep3D(target, transform = {}, steps = 0) {
  const heading = (90 - finiteOr(target?.direction, 90) + finiteOr(transform.yaw, 0)) * Math.PI / 180;
  const pitch = finiteOr(transform.pitch, 0) * Math.PI / 180;
  const distance = finiteOr(steps, 0);
  const horizontal = distance * Math.cos(pitch);
  return {
    x: finiteOr(target?.x, 0) + horizontal * Math.cos(heading),
    y: finiteOr(target?.y, 0) + horizontal * Math.sin(heading),
    z: finiteOr(transform.height, 0) * SCRATCH_UNITS_PER_WORLD_UNIT + distance * Math.sin(pitch),
  };
}

export function sanitizeObjectHierarchy(objects) {
  if (!Array.isArray(objects) || objects.length === 0) return objects || [];

  const byId = new Map(objects.map((object) => [object.id, object]));
  const complete = new Set();

  // Parent links form a directed graph with at most one outgoing edge per
  // object. Walk iteratively so deeply nested or hostile project data cannot
  // exhaust the JavaScript call stack.
  for (const start of objects) {
    if (!start || complete.has(start.id)) continue;

    const path = [];
    const active = new Set();
    let current = start;

    while (current && !complete.has(current.id)) {
      if (active.has(current.id)) {
        // The last node points back into this walk. Detach that edge to turn
        // the graph into a tree while retaining the rest of the hierarchy.
        const edge = path[path.length - 1];
        if (edge) edge.parent = null;
        break;
      }

      active.add(current.id);
      path.push(current);

      if (current.parent == null) break;
      const parent = byId.get(current.parent);
      if (!parent || parent === current) {
        current.parent = null;
        break;
      }
      current = parent;
    }

    for (const object of path) complete.add(object.id);
  }

  return objects;
}

const listen = (emitter, event, handler, subscriptions) => {
  if (typeof emitter?.on !== "function") return;
  emitter.on(event, handler);
  subscriptions.push([emitter, event, handler]);
};

const unlisten = ([emitter, event, handler]) => {
  if (typeof emitter?.off === "function") emitter.off(event, handler);
  else if (typeof emitter?.removeListener === "function") {
    emitter.removeListener(event, handler);
  }
};

/**
 * Owns the TurboWarp runtime subscriptions used by the 3D stage.
 * Binding tracks both the VM and its runtime so replacing either cannot leave
 * stale tick listeners or native-renderer hooks behind.
 */
export class Runtime3DBridge {
  constructor({ onStart, onStop, onTick, onChange } = {}) {
    this.handlers = { onStart, onStop, onTick, onChange };
    this.vm = null;
    this.runtime = null;
    this.subscriptions = [];
  }

  bind(vm) {
    const runtime = vm?.runtime || null;
    if (this.vm === vm && this.runtime === runtime) return false;

    this.detach();
    this.vm = vm || null;
    this.runtime = runtime;

    const subscriptions = this.subscriptions;
    const { onStart, onStop, onTick, onChange } = this.handlers;
    for (const event of ["PROJECT_RUN_START", "RUNTIME_STARTED"]) {
      listen(this.vm, event, onStart, subscriptions);
    }
    for (const event of ["PROJECT_RUN_STOP", "RUNTIME_STOPPED"]) {
      listen(this.vm, event, onStop, subscriptions);
    }
    for (const event of ["PROJECT_CHANGED", "TARGETS_UPDATE"]) {
      listen(this.vm, event, onChange, subscriptions);
    }
    listen(this.runtime, "AFTER_EXECUTE", onTick, subscriptions);
    return true;
  }

  detach() {
    for (const subscription of this.subscriptions) unlisten(subscription);
    this.subscriptions.length = 0;
    this.vm = null;
    this.runtime = null;
  }
}
