// Project settings are data, not navigation. Changing them must never refresh
// Blockly, restart scripts, or rebuild the VM. Legacy config comments still load
// through TurboWarp; this snapshot takes precedence when present in an archive.
const installed = new WeakSet();
const sameOptions = (current, next) => Object.keys(next).every(key => Object.is(current?.[key], next[key]));

export function stageDimensions(width, height) {
  if (width === "" || height === "") return null;
  width = Number(width);
  height = Number(height);
  if (!Number.isFinite(width) || !Number.isFinite(height) || width <= 0 || height <= 0) return null;
  return [Math.min(4096, Math.max(1, Math.round(width))), Math.min(4096, Math.max(1, Math.round(height)))];
}

export function captureRuntimeSettings(vm) {
  const runtime = vm?.runtime;
  if (!runtime) return undefined;
  return {
    version: 2,
    width: runtime.stageWidth,
    height: runtime.stageHeight,
    framerate: runtime.frameLoop?.framerate,
    turbo: !!runtime.turboMode,
    interpolation: !!runtime.interpolationEnabled,
    highQualityPen: !!runtime.renderer?.useHighQualityRender,
    maxClones: runtime.runtimeOptions?.maxClones === Infinity ? "Infinity" : runtime.runtimeOptions?.maxClones,
    fencing: !!runtime.runtimeOptions?.fencing,
    miscLimits: !!runtime.runtimeOptions?.miscLimits,
    warpTimer: !!runtime.compilerOptions?.warpTimer,
    compilerEnabled: !!runtime.compilerOptions?.enabled,
  };
}

export function restoreRuntimeSettings(vm, settings) {
  if (!vm || !settings || typeof settings !== "object") return;
  const compiler = {};
  if (typeof settings.warpTimer === "boolean") compiler.warpTimer = settings.warpTimer;
  if (typeof settings.compilerEnabled === "boolean") compiler.enabled = settings.compilerEnabled;
  if (Object.keys(compiler).length && typeof vm.setCompilerOptions === "function") {
    vm.setCompilerOptions(compiler);
  }
  // Older project archives stored only compiler settings.
  if (settings.version !== 2) return;
  const dimensions = stageDimensions(settings.width, settings.height);
  if (dimensions && typeof vm.setStageSize === "function") vm.setStageSize(...dimensions);
  if (Number.isFinite(settings.framerate) && settings.framerate >= 0 && typeof vm.setFramerate === "function") {
    vm.setFramerate(settings.framerate);
  }
  if (typeof settings.turbo === "boolean" && typeof vm.setTurboMode === "function") vm.setTurboMode(settings.turbo);
  if (typeof settings.interpolation === "boolean" && typeof vm.setInterpolation === "function") {
    vm.setInterpolation(settings.interpolation);
  }
  const options = {};
  if (settings.maxClones === "Infinity") options.maxClones = Infinity;
  else if (Number.isFinite(settings.maxClones) && settings.maxClones >= 0) options.maxClones = settings.maxClones;
  for (const key of ["fencing", "miscLimits"]) {
    if (typeof settings[key] === "boolean") options[key] = settings[key];
  }
  if (Object.keys(options).length && typeof vm.setRuntimeOptions === "function") vm.setRuntimeOptions(options);
  const renderer = vm.runtime?.renderer;
  if (typeof settings.highQualityPen === "boolean" && renderer?.useHighQualityRender !== settings.highQualityPen) {
    renderer?.setUseHighQualityRender?.(settings.highQualityPen);
  }
}

export function installRuntimeSettings(vm, isLoading = () => false) {
  if (!vm || (typeof vm !== "object" && typeof vm !== "function")) return;
  if (installed.has(vm)) return;
  installed.add(vm);
  let changePending = false;
  const changed = () => {
    const runtime = vm.runtime;
    const target = runtime?.getTargetForStage?.();
    if (!target || isLoading() || changePending) return;
    changePending = true;
    // Combine synchronous changes without touching workspace XML. The snapshot
    // is captured synchronously at export, even if this notification is pending.
    queueMicrotask(() => {
      changePending = false;
      const currentRuntime = vm.runtime;
      if (
        !isLoading() &&
        currentRuntime?.getTargetForStage?.() === target
      ) {
        currentRuntime.emitProjectChanged?.();
      }
    });
  };
  const wrap = (name, prepare) => {
    if (typeof vm[name] !== "function") return;
    const original = vm[name].bind(vm);
    vm[name] = (...args) => {
      const next = prepare(...args);
      if (!next) return;
      const result = original(...next);
      changed();
      return result;
    };
  };
  wrap("setStageSize", (width, height) => {
    const runtime = vm.runtime;
    const next = stageDimensions(width, height);
    return next &&
      (!runtime || next[0] !== runtime.stageWidth || next[1] !== runtime.stageHeight)
      ? next
      : null;
  });
  wrap("setFramerate", value => {
    const runtime = vm.runtime;
    if (value === "" || !Number.isFinite(Number(value))) return null;
    const fps = Number(value) < 0 ? 1 : Math.min(250, Number(value));
    return !runtime?.frameLoop || fps !== runtime.frameLoop.framerate ? [fps] : null;
  });
  wrap("setTurboMode", value => {
    const runtime = vm.runtime;
    return !runtime || !!value !== runtime.turboMode ? [!!value] : null;
  });
  wrap("setInterpolation", value => {
    const runtime = vm.runtime;
    return !runtime || !!value !== runtime.interpolationEnabled ? [!!value] : null;
  });
  for (const [method, field] of [["setRuntimeOptions", "runtimeOptions"], ["setCompilerOptions", "compilerOptions"]]) {
    wrap(method, options => {
      const runtime = vm.runtime;
      return options && (!runtime || !sameOptions(runtime[field], options)) ? [options] : null;
    });
  }
}
