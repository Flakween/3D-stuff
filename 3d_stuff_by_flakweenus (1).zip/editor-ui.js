export function editorMarkup(icon) {
  const field = (label, content, extra = '') => `<label class="d3-field-block" ${extra}><span>${label}</span>${content}</label>`;
  const pop = (name, label, body) => `<div class="d3-popup d3-${name}" role="dialog" aria-label="${label}" hidden><div class="d3-popup-heading"><strong>${label}</strong><button data-action="close-pop" aria-label="Close">×</button></div>${body}</div>`;
  const button = (name, label, extra = '') => `<button class="d3-option-button" data-pop="${name}" aria-expanded="false" ${extra}>${label}<span class="d3-caret"></span></button>`;
  const maps = [['texture','Base color'],['roughness','Roughness'],['metallic','Metallic'],['normal','Normal'],['opacity','Opacity']];
  return `
    <aside class="d3-assets" aria-label="3D models">
      <div class="d3-model-list" role="list" aria-label="Models"></div>
      <div class="d3-add-wrap">
        <button class="d3-add-fab" data-action="add-menu" title="Add a model" aria-label="Add a model">+</button>
        <div class="d3-add-menu" hidden><button data-action="empty">New empty model</button><button data-action="import">Import GLB, glTF, OBJ</button></div>
        <input class="d3-import" type="file" accept=".glb,.gltf,.obj" hidden>
      </div>
    </aside>
    <main class="d3-workspace">
      <header class="d3-topbar">
        <div class="d3-toolbar-row d3-toolbar-first">
          <div class="d3-name-group">
            ${field('Model','<input class="d3-model-name" aria-label="Model name">')}
            ${field('Object','<input class="d3-object-name" aria-label="Object name" placeholder="Select an object">')}
          </div>
          <div class="d3-common-actions">
            <button data-action="copy" data-requires-selection title="Copy">${icon('copy',19)}</button>
            <button data-action="paste" title="Paste" disabled>${icon('paste',19)}</button>
            <button data-action="delete" data-requires-selection title="Delete">${icon('delete',19)}</button>
            <button data-action="undo" title="Undo (Ctrl+Z)">${icon('undo',19)}</button>
            <button data-action="redo" title="Redo (Ctrl+Y)">${icon('redo',19)}</button>
          </div>
        </div>
        <div class="d3-toolbar-row d3-toolbar-second">
          <div class="d3-selection-extra" hidden>
            <button class="d3-box-toggle" data-action="box" aria-pressed="false">Box select</button>
            <select class="d3-filter" aria-label="Selection filter">${[['all','All objects'],['cube','Cubes'],['sphere','Spheres'],['cone','Cones'],['cylinder','Cylinders'],['plane','Planes'],['torus','Tori'],['star','Stars'],['import','Imports']].map(([v,l])=>`<option value="${v}">${l}</option>`).join('')}</select>
            <div class="d3-parent-actions" role="group" aria-label="Parenting">
              <button data-action="parent" title="Parent to the last selected object">Parent</button>
              <button class="d3-chain" data-action="chain" title="Last selected is the root; earlier objects form a chain">Parent chain</button>
            </div>
          </div>
          <div class="d3-transform-tools" hidden>
            <select class="d3-transform" aria-label="Gizmo handles"><option value="all">All</option><option value="move">Move</option><option value="rotate">Rotate</option><option value="scale">Scale</option></select>
            <select class="d3-space" aria-label="Transform space" title="Edit Local moves the saved pivot without moving the object"><option value="world">World</option><option value="local">Local</option><option value="pivot">Edit Local</option></select>
            ${button('inspector-panel','Transform')}
          </div>
          <div class="d3-shape-options" hidden>
            ${button('mesh-menu','Cube')}
            <label class="d3-inline-check"><input class="d3-snap" type="checkbox" checked>Snap</label>
          </div>
          ${field('Color',`<button class="d3-swatch-picker" data-pop="color-panel" aria-label="Color" aria-expanded="false"><span class="d3-color-swatch"></span><span class="d3-swatch-arrow"><span class="d3-caret"></span></span></button>`, 'data-requires-one')}
          ${field('Material',`<button class="d3-option-button" data-pop="maps" aria-expanded="false"><span class="d3-material-swatch"></span>Textures<span class="d3-caret"></span></button>`, 'data-requires-one')}
          <div class="d3-geometry-options">
            ${field('Subdivisions',`<span class="d3-stepper"><input class="d3-subdiv" type="number" min="1" max="16" value="1" aria-label="Subdivisions" title="Refinement: 1, 2, 4, 8, or 16"><span class="d3-step-buttons"><button data-action="subdiv-up" aria-label="Increase subdivisions">▴</button><button data-action="subdiv-down" aria-label="Decrease subdivisions">▾</button></span></span>`, 'data-requires-one')}
            <label class="d3-inline-check" data-requires-one title="Subdivide without smoothing; preserve sharp edges"><input class="d3-linear" type="checkbox">Linear</label>
            <label class="d3-star-only">Points <input class="d3-points" type="number" min="3" max="24" value="5"></label>
            <label class="d3-star-only">Inner angle <input class="d3-inner" type="number" min="30" max="175" value="120">°</label>
          </div>
        </div>
        ${pop('color-panel','Color',`<input type="color" class="d3-color" value="#ffffff" aria-label="Choose color"><label>Hex <input type="text" class="d3-color-hex" aria-label="Hex color" maxlength="7" value="#ffffff"></label><div class="d3-color-sliders">${['metallic','smoothness','opacity'].map(k=>`<label>${k[0].toUpperCase()+k.slice(1)} <output data-output="${k}"></output><input type="range" class="d3-${k}" min="0" max="1" step=".01" aria-label="${k}"></label>`).join('')}</div>`)}
        ${pop('maps','Material textures',maps.map(([k,l])=>`<div class="d3-map-row"><img data-preview="${k}" alt="" hidden><span class="d3-map-placeholder" data-placeholder="${k}">+</span><label>${l}<span class="d3-map-file" data-map-name="${k}">No texture</span><input type="file" data-map="${k}" accept="image/*" aria-label="Upload ${l} texture"></label><button data-remove-map="${k}" aria-label="Remove ${l} texture">×</button></div>`).join(''))}
        ${pop('mesh-menu','Shapes','<div class="d3-shape-grid"></div>')}
        ${pop('inspector-panel','Transform',`<div class="d3-inspector"><span class="d3-selection-count"></span><div class="d3-transform-inspector">${['position','rotation','scale'].map(p=>`<fieldset><legend>${p[0].toUpperCase()+p.slice(1)}${p==='rotation'?' (°)':''}</legend>${['X','Y','Z'].map((a,i)=>`<label>${a}<input class="d3-transform-field" data-transform="${p}" data-axis="${i}" type="number" step="${p==='rotation'?1:.1}" aria-label="${p} ${a}"></label>`).join('')}</fieldset>`).join('')}</div></div>`)}
      </header>
      <div class="d3-center">
        <nav class="d3-tools" role="toolbar" aria-label="Model tools"></nav>
        <div class="d3-view" aria-label="3D model canvas"><canvas class="d3-canvas" aria-label="3D model editor canvas"></canvas><div class="d3-box" hidden></div><div class="d3-hierarchy" aria-label="Object hierarchy"><span class="d3-tree-root">Model</span><div class="d3-hierarchy-items"></div></div><div class="d3-status" role="status" hidden></div></div>
      </div>
      <footer class="d3-bottom">
        <div class="d3-view-options"><select class="d3-view-mode" aria-label="Viewport shading"><option value="madcap">Matcap</option><option value="unlit">Unlit</option><option value="rendered">Rendered</option></select>${button('view-settings','Settings')}</div>
        <div class="d3-bottom-controls"><div class="d3-segmented"><button data-action="wireframe" title="Wireframe" aria-label="Wireframe">${icon('wire')}</button><button class="d3-hierarchy-toggle" title="Hierarchy" aria-label="Hierarchy">${icon('tree')}</button><button data-action="grid" title="Grid" aria-label="Grid">${icon('grid')}</button></div><div class="d3-segmented"><button data-action="zoom-out" title="Zoom out">${icon('zoomOut',18)}</button><button data-action="zoom-reset" title="Frame model">${icon('zoomReset',18)}</button><button data-action="zoom-in" title="Zoom in">${icon('zoomIn',18)}</button></div><button data-action="export" class="d3-export">Export</button></div>
        ${pop('view-settings','View settings',`<label>Background <input class="d3-background" type="color" value="#000000" aria-label="Viewport background"></label><label class="d3-exposure-row">Exposure <input class="d3-exposure" type="range" min=".5" max="2.5" step=".05" value="1.25"></label><button data-action="shadows" aria-pressed="true">Shadows</button>`)}
      </footer>
    </main>`;
}
